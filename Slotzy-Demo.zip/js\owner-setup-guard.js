import * as dataStore from "./dataStore.js";

(function () {
  const path = String(window.location.pathname ?? "").toLowerCase();
  if (path.endsWith("/owner-setup.html")) return;

  const sessionUser = dataStore.getSessionUser();
  const username = String(sessionUser?.username ?? "").trim();
  const role = String(sessionUser?.role ?? "").trim().toLowerCase();
  if (!username || role !== "owner") return;

  if (!isOwnerFirstRun(username)) return;

  const target = new URL("./owner-setup.html", window.location.href);
  window.location.replace(target.href);
})();

function isOwnerFirstRun(username) {
  const users = dataStore.getUsers();
  const owner = users.find((user) => {
    const userName = String(user?.username ?? "").trim();
    const userRole = String(user?.role ?? "").trim().toLowerCase();
    return userName === username && userRole === "owner";
  });
  if (!owner) return false;

  const ownerShopId = String(owner?.shopId ?? "").trim();
  const hasShop = Boolean(ownerShopId && dataStore.getShopById(ownerShopId));

  const hasServices = dataStore.getServices().some((service) => {
    if (ownerShopId) {
      return String(service?.shopId ?? "").trim() === ownerShopId;
    }
    const barberUsername = String(service?.barberUsername ?? service?.ownerUsername ?? "").trim();
    return barberUsername === username;
  });

  const hasAvailability = hasOwnerAvailability({ username, ownerShopId, users });
  return !hasShop && !hasServices && !hasAvailability;
}

function hasOwnerAvailability({ username, ownerShopId, users }) {
  const availabilityMap = dataStore.getAvailabilityMap();

  if (ownerShopId) {
    const staffUsernames = users
      .filter((user) => String(user?.shopId ?? "").trim() === ownerShopId)
      .filter((user) => {
        const role = String(user?.role ?? "").trim().toLowerCase();
        return role === "owner" || role === "barber";
      })
      .map((user) => String(user?.username ?? "").trim())
      .filter(Boolean);

    return staffUsernames.some((staffUsername) =>
      hasEnabledWeeklyHours(availabilityMap?.[staffUsername])
    );
  }

  return hasEnabledWeeklyHours(availabilityMap?.[username]);
}

function hasEnabledWeeklyHours(entry) {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) return false;
  const weekly = entry?.weekly;
  if (!weekly || typeof weekly !== "object" || Array.isArray(weekly)) return false;
  const dayKeys = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
  return dayKeys.some((dayKey) => Boolean(weekly?.[dayKey]?.enabled));
}
