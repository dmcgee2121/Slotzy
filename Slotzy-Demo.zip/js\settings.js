import * as dataStore from "./dataStore.js";
import { wireLogoutButton } from "./logout.js";

(function () {
  const settingsMain = document.getElementById("settingsMain");
  const backBtn = document.getElementById("backBtn");
  const fullNameInput = document.getElementById("fullNameInput");
  const emailInput = document.getElementById("emailInput");
  const phoneInput = document.getElementById("phoneInput");
  const profileCompletenessText = document.getElementById("profileCompletenessText");
  const profileProgressBar = document.getElementById("profileProgressBar");
  const missingFields = document.getElementById("missingFields");
  const saveProfileBtn = document.getElementById("saveProfileBtn");
  const profileStatus = document.getElementById("profileStatus");

  const shopSettingsCard = document.getElementById("shopSettingsCard");
  const businessNameInput = document.getElementById("businessNameInput");
  const shopPhoneInput = document.getElementById("shopPhoneInput");
  const shopEmailInput = document.getElementById("shopEmailInput");
  const address1Input = document.getElementById("address1Input");
  const cityInput = document.getElementById("cityInput");
  const stateInput = document.getElementById("stateInput");
  const zipInput = document.getElementById("zipInput");
  const cancelHoursInput = document.getElementById("cancelHoursInput");
  const bufferMinutesInput = document.getElementById("bufferMinutesInput");
  const requireDepositInput = document.getElementById("requireDepositInput");
  const depositAmountInput = document.getElementById("depositAmountInput");
  const lateGraceMinutesInput = document.getElementById("lateGraceMinutesInput");
  const noShowStrikeLimitInput = document.getElementById("noShowStrikeLimitInput");
  const allowSameDayInput = document.getElementById("allowSameDayInput");
  const maxDaysAdvanceInput = document.getElementById("maxDaysAdvanceInput");
  const saveShopBtn = document.getElementById("saveShopBtn");
  const shopStatus = document.getElementById("shopStatus");
  const publicBookingLinkInput = document.getElementById("publicBookingLinkInput");
  const copyPublicBookingLinkBtn = document.getElementById("copyPublicBookingLinkBtn");
  const openPublicBookingLinkBtn = document.getElementById("openPublicBookingLinkBtn");
  const publicBookingLinkStatus = document.getElementById("publicBookingLinkStatus");
  const publicBookingQrImage = document.getElementById("publicBookingQrImage");
  const publicBookingQrEmpty = document.getElementById("publicBookingQrEmpty");
  const downloadPublicBookingQrBtn = document.getElementById("downloadPublicBookingQrBtn");
  const printPublicBookingQrBtn = document.getElementById("printPublicBookingQrBtn");
  const publicBookingQrStatus = document.getElementById("publicBookingQrStatus");
  const demoModeCard = document.getElementById("demoModeCard");
  const resetDemoBtn = document.getElementById("resetDemoBtn");
  const copyDemoOwnerBtn = document.getElementById("copyDemoOwnerBtn");
  const copyDemoClientBtn = document.getElementById("copyDemoClientBtn");
  const demoStatus = document.getElementById("demoStatus");

  const barberDisplayNameInput = document.getElementById("barberDisplayNameInput");
  const barberUsernameInput = document.getElementById("barberUsernameInput");
  const barberPasswordInput = document.getElementById("barberPasswordInput");
  const addBarberUserBtn = document.getElementById("addBarberUserBtn");
  const barberUserStatus = document.getElementById("barberUserStatus");
  const barberUsersList = document.getElementById("barberUsersList");

  const showToast = window.showToast;
  let saveFeedbackTimer = null;
  let publicBookingQrDataUrl = "";
  const DEMO_LOGIN_CREDENTIALS = {
    owner: { username: "owner_demo", password: "demo" },
    client: { username: "client_demo", password: "demo" },
    jordan: { username: "jordan_demo", password: "demo" },
    alex: { username: "alex_demo", password: "demo" },
  };

  const currentUser = getCurrentUser();
  const currentUsername = getUsername(currentUser);
  const currentRole = getRole(currentUser);

  init();

  function init() {
    if (!currentUsername || !currentRole) {
      renderLoggedOutState();
      return;
    }

    wireLogoutButton({ redirectPath: "../index.html" });

    backBtn?.addEventListener("click", (event) => {
      event.preventDefault();
      if (currentRole === "customer") {
        window.location.href = "customer-dashboard.html";
      } else {
        window.location.href = "business-owner.html";
      }
    });

    loadProfile();
    bindCompletenessEvents();
    updateProfileCompleteness();
    saveProfileBtn?.addEventListener("click", handleSaveProfile);
    configureShopSettings();
    configureDemoModeControls();
  }

  function getCurrentUser() {
    return dataStore.getSessionUser();
  }

  function getUsername(user) {
    if (!user || typeof user !== "object") return "";
    return String(user.username ?? "").trim();
  }

  function getRole(user) {
    if (!user || typeof user !== "object") return "";
    const role = String(user.role ?? "").trim().toLowerCase();
    if (role === "owner") return "owner";
    if (role === "barber") return "barber";
    if (role === "customer") return "customer";
    return "";
  }

  function getProfilesMap() {
    return dataStore.getProfiles();
  }

  function saveProfilesMap(profilesMap) {
    dataStore.saveProfiles(profilesMap);
  }

  function loadProfile() {
    const profiles = getProfilesMap();
    const profile = profiles[currentUsername];
    if (!profile || typeof profile !== "object") return;

    if (fullNameInput) fullNameInput.value = String(profile.fullName ?? "");
    if (emailInput) emailInput.value = String(profile.email ?? "");
    if (phoneInput) phoneInput.value = String(profile.phone ?? "");
  }

  function handleSaveProfile() {
    if (!saveProfileBtn || saveProfileBtn.disabled) return;
    clearProfileStatus();

    const fullName = String(fullNameInput?.value ?? "").trim();
    const email = String(emailInput?.value ?? "").trim();
    const phone = String(phoneInput?.value ?? "").trim();
    const phoneDigits = phone.replace(/\D/g, "");

    if (fullName && fullName.length < 2) {
      setProfileStatus("Full name must be at least 2 characters.", false);
      return;
    }
    if (email && (!email.includes("@") || !email.includes("."))) {
      setProfileStatus("Please enter a valid email address.", false);
      return;
    }
    if (phone && phoneDigits.length < 10) {
      setProfileStatus("Please enter a valid phone number with at least 10 digits.", false);
      return;
    }

    const profiles = getProfilesMap();
    profiles[currentUsername] = {
      fullName,
      email,
      phone,
      phoneDigits,
      updatedAt: new Date().toISOString(),
    };
    saveProfilesMap(profiles);
    setProfileStatus("Profile saved successfully.", true);
    notifyProfileSaved();
    applySavedButtonFeedback();
    updateProfileCompleteness();
  }

  function configureShopSettings() {
    if (!shopSettingsCard) return;
    if (currentRole !== "owner") {
      shopSettingsCard.classList.add("hidden");
      return;
    }

    shopSettingsCard.classList.remove("hidden");
    requireDepositInput?.addEventListener("change", applyDepositToggleState);
    loadShopSettings();
    saveShopBtn?.addEventListener("click", handleSaveShopSettings);
    copyPublicBookingLinkBtn?.addEventListener("click", handleCopyPublicBookingLink);
    openPublicBookingLinkBtn?.addEventListener("click", handleOpenPublicBookingLink);
    downloadPublicBookingQrBtn?.addEventListener("click", handleDownloadPublicBookingQr);
    printPublicBookingQrBtn?.addEventListener("click", handlePrintPublicBookingQr);
    addBarberUserBtn?.addEventListener("click", handleAddBarberUser);
    renderShopTeam();
  }

  function configureDemoModeControls() {
    if (!demoModeCard || !resetDemoBtn) return;
    if (!dataStore.isDemoMode()) {
      demoModeCard.classList.add("hidden");
      clearDemoStatus();
      return;
    }

    demoModeCard.classList.remove("hidden");
    if (resetDemoBtn.dataset.bound !== "true") {
      resetDemoBtn.addEventListener("click", handleResetDemoClick);
      resetDemoBtn.dataset.bound = "true";
    }
    if (copyDemoOwnerBtn && copyDemoOwnerBtn.dataset.bound !== "true") {
      copyDemoOwnerBtn.addEventListener("click", () => handleCopyDemoLogin("owner"));
      copyDemoOwnerBtn.dataset.bound = "true";
    }
    if (copyDemoClientBtn && copyDemoClientBtn.dataset.bound !== "true") {
      copyDemoClientBtn.addEventListener("click", () => handleCopyDemoLogin("client"));
      copyDemoClientBtn.dataset.bound = "true";
    }
  }

  function handleResetDemoClick() {
    clearDemoStatus();
    const confirmed = window.confirm("Reset demo data to the original sample set?");
    if (!confirmed) return;
    setDemoStatus("Resetting demo data...", true);
    window.location.href = "../index.html?reset=1&demo=1";
  }

  async function handleCopyDemoLogin(accountType) {
    clearDemoStatus();
    const credentials = DEMO_LOGIN_CREDENTIALS[accountType];
    if (!credentials) {
      setDemoStatus("Demo login is unavailable.", false);
      return;
    }

    const payload = `Username: ${credentials.username}\nPassword: ${credentials.password}`;
    try {
      const copied = await copyText(payload);
      if (!copied) throw new Error("copy_failed");
      const label = accountType === "owner" ? "Owner" : "Client";
      setDemoStatus(`${label} demo login copied.`, true);
      showToast?.(`${label} demo login copied.`, "success");
    } catch {
      setDemoStatus("Could not copy demo login. Please copy it manually.", false);
    }
  }

  function getCurrentOwnerRecord() {
    const users = dataStore.getUsers();
    return users.find((user) => String(user?.username ?? "") === currentUsername) || null;
  }

  function ensureCurrentShop() {
    const users = dataStore.getUsers();
    const shops = dataStore.getShops();
    const owner = users.find((user) => String(user?.username ?? "") === currentUsername);
    if (!owner) return shops[0] || null;

    let targetShopId = String(owner?.shopId ?? "").trim();
    if (!targetShopId) {
      targetShopId = shops[0]?.id || "";
    }

    let targetShop = dataStore.getShopById(targetShopId);
    if (!targetShop) {
      const nextShopName = getLegacyShopName();
      targetShop = {
        id: createId("shop"),
        name: nextShopName,
        slug: toSlug(nextShopName),
        createdAtISO: new Date().toISOString(),
      };
      dataStore.saveShops([...shops, targetShop]);
      targetShopId = targetShop.id;
    }

    if (owner.shopId !== targetShopId) {
      const nextUsers = users.map((user) => (
        String(user?.username ?? "") === currentUsername
          ? { ...user, shopId: targetShopId }
          : user
      ));
      dataStore.saveUsers(nextUsers);
    }

    return targetShop;
  }

  function getLegacyShopName() {
    const legacyShop = dataStore.getShop();
    return String(legacyShop?.businessName ?? legacyShop?.name ?? "My Shop").trim() || "My Shop";
  }

  function loadShopSettings() {
    const shop = ensureCurrentShop();
    const legacyShop = dataStore.getShop() || {};
    const policyDefaults = getDefaultBookingPolicy();
    const policy = legacyShop.bookingPolicy && typeof legacyShop.bookingPolicy === "object"
      ? legacyShop.bookingPolicy
      : {};
    const address = legacyShop.address && typeof legacyShop.address === "object" ? legacyShop.address : {};

    if (businessNameInput) {
      businessNameInput.value = String(shop?.name ?? legacyShop.businessName ?? "");
    }
    if (shopPhoneInput) shopPhoneInput.value = String(legacyShop.shopPhone ?? "");
    if (shopEmailInput) shopEmailInput.value = String(legacyShop.shopEmail ?? "");
    if (address1Input) address1Input.value = String(address.line1 ?? "");
    if (cityInput) cityInput.value = String(address.city ?? "");
    if (stateInput) stateInput.value = String(address.state ?? "");
    if (zipInput) zipInput.value = String(address.zip ?? "");

    if (allowSameDayInput) allowSameDayInput.checked = Boolean(
      policy.allowSameDay ?? policyDefaults.allowSameDay
    );
    if (maxDaysAdvanceInput) {
      maxDaysAdvanceInput.value = String(
        clampNumber(policy.maxDaysAdvance, 1, 365, policyDefaults.maxDaysAdvance)
      );
    }
    if (cancelHoursInput) {
      cancelHoursInput.value = String(
        clampNumber(policy.cancelHours, 0, 168, policyDefaults.cancelHours)
      );
    }
    if (bufferMinutesInput) {
      bufferMinutesInput.value = String(
        clampNumber(policy.bufferMinutes, 0, 180, policyDefaults.bufferMinutes)
      );
    }
    if (requireDepositInput) {
      requireDepositInput.checked = Boolean(policy.requireDeposit ?? policyDefaults.requireDeposit);
    }
    if (depositAmountInput) {
      const amount = toNonNegativeMoney(policy.depositAmount);
      depositAmountInput.value = amount === null ? "" : String(amount);
    }
    if (lateGraceMinutesInput) {
      lateGraceMinutesInput.value = String(
        clampNumber(policy.lateGraceMinutes, 0, 120, policyDefaults.lateGraceMinutes)
      );
    }
    if (noShowStrikeLimitInput) {
      noShowStrikeLimitInput.value = String(
        clampNumber(policy.noShowStrikeLimit, 0, 10, policyDefaults.noShowStrikeLimit)
      );
    }
    updatePublicBookingLink(shop);
    applyDepositToggleState();
  }

  function handleSaveShopSettings() {
    if (currentRole !== "owner") return;
    clearShopStatus();

    const businessName = String(businessNameInput?.value ?? "").trim();
    const shopPhone = String(shopPhoneInput?.value ?? "").trim();
    const shopEmail = String(shopEmailInput?.value ?? "").trim();
    const address1 = String(address1Input?.value ?? "").trim();
    const city = String(cityInput?.value ?? "").trim();
    const state = String(stateInput?.value ?? "").trim();
    const zip = String(zipInput?.value ?? "").trim();
    const cancelHours = clampNumber(cancelHoursInput?.value, 0, 168, 24);
    const bufferMinutes = clampNumber(bufferMinutesInput?.value, 0, 180, 0);
    const allowSameDay = Boolean(allowSameDayInput?.checked);
    const maxDaysAdvance = clampNumber(maxDaysAdvanceInput?.value, 1, 365, 30);
    const requireDeposit = Boolean(requireDepositInput?.checked);
    const depositAmount = toNonNegativeMoney(depositAmountInput?.value);
    const lateGraceMinutes = clampNumber(lateGraceMinutesInput?.value, 0, 120, 10);
    const noShowStrikeLimit = clampNumber(noShowStrikeLimitInput?.value, 0, 10, 2);

    if (businessName.length < 2) {
      setShopStatus("Business name must be at least 2 characters.", false);
      return;
    }
    if (shopEmail && (!shopEmail.includes("@") || !shopEmail.includes("."))) {
      setShopStatus("Please enter a valid shop email address.", false);
      return;
    }
    if (requireDeposit && (depositAmount === null || depositAmount <= 0)) {
      setShopStatus("Please enter a deposit amount when deposits are required.", false);
      return;
    }

    const ownerRecord = getCurrentOwnerRecord();
    const ownerShopId = String(ownerRecord?.shopId ?? "").trim();
    const shops = dataStore.getShops();
    let nextShopId = ownerShopId;
    if (!nextShopId) {
      nextShopId = createId("shop");
    }

    const updatedShop = {
      id: nextShopId,
      name: businessName,
      slug: toSlug(businessName),
      createdAtISO: (
        dataStore.getShopById(nextShopId)?.createdAtISO ||
        new Date().toISOString()
      ),
    };

    const existingIndex = shops.findIndex((shop) => String(shop?.id ?? "") === nextShopId);
    const nextShops = [...shops];
    if (existingIndex >= 0) nextShops[existingIndex] = updatedShop;
    else nextShops.push(updatedShop);
    dataStore.saveShops(nextShops);

    if (!ownerShopId) {
      const users = dataStore.getUsers().map((user) => (
        String(user?.username ?? "") === currentUsername
          ? { ...user, shopId: nextShopId }
          : user
      ));
      dataStore.saveUsers(users);
    }

    const legacyShopPayload = {
      businessName,
      shopPhone,
      shopEmail,
      address: {
        line1: address1,
        city,
        state,
        zip,
      },
      bookingPolicy: {
        allowSameDay,
        maxDaysAdvance,
        cancelHours,
        bufferMinutes,
        requireDeposit,
        depositAmount: requireDeposit ? depositAmount : 0,
        lateGraceMinutes,
        noShowStrikeLimit,
      },
      shopId: nextShopId,
      updatedAt: new Date().toISOString(),
    };
    dataStore.saveShop(legacyShopPayload);

    if (cancelHoursInput) cancelHoursInput.value = String(cancelHours);
    if (bufferMinutesInput) bufferMinutesInput.value = String(bufferMinutes);
    if (maxDaysAdvanceInput) maxDaysAdvanceInput.value = String(maxDaysAdvance);
    if (lateGraceMinutesInput) lateGraceMinutesInput.value = String(lateGraceMinutes);
    if (noShowStrikeLimitInput) noShowStrikeLimitInput.value = String(noShowStrikeLimit);
    if (depositAmountInput) {
      depositAmountInput.value = requireDeposit ? String(depositAmount) : "";
    }
    updatePublicBookingLink(updatedShop);
    applyDepositToggleState();
    renderShopTeam();

    setShopStatus("Shop settings saved successfully.", true);
  }

  function getCurrentShopId() {
    const owner = getCurrentOwnerRecord();
    const direct = String(owner?.shopId ?? "").trim();
    if (direct) return direct;
    const fallback = dataStore.getShops()[0];
    return String(fallback?.id ?? "");
  }

  function handleAddBarberUser() {
    clearBarberUserStatus();
    const shopId = getCurrentShopId();
    if (!shopId) {
      setBarberUserStatus("Save shop settings first so we can assign the barber to a shop.", false);
      return;
    }

    const displayName = String(barberDisplayNameInput?.value ?? "").trim();
    const username = String(barberUsernameInput?.value ?? "").trim();
    const password = String(barberPasswordInput?.value ?? "").trim();

    if (displayName.length < 2) {
      setBarberUserStatus("Display name must be at least 2 characters.", false);
      return;
    }
    if (!/^[a-zA-Z0-9._-]{3,32}$/.test(username)) {
      setBarberUserStatus("Username must be 3-32 chars using letters, numbers, dot, dash, or underscore.", false);
      return;
    }
    if (password.length < 4) {
      setBarberUserStatus("Password must be at least 4 characters.", false);
      return;
    }

    const users = dataStore.getUsers();
    const duplicate = users.some((user) => String(user?.username ?? "").toLowerCase() === username.toLowerCase());
    if (duplicate) {
      setBarberUserStatus("That username is already in use.", false);
      return;
    }

    users.push({
      username,
      password,
      role: "barber",
      shopId,
      displayName,
    });
    dataStore.saveUsers(users);

    if (barberDisplayNameInput) barberDisplayNameInput.value = "";
    if (barberUsernameInput) barberUsernameInput.value = "";
    if (barberPasswordInput) barberPasswordInput.value = "";
    setBarberUserStatus("Barber added to your shop.", true);
    showToast?.("Barber account created.", "success");
    renderShopTeam();
  }

  function renderShopTeam() {
    if (!barberUsersList) return;
    const shopId = getCurrentShopId();
    const users = dataStore.getUsers()
      .filter((user) => String(user?.shopId ?? "") === shopId)
      .filter((user) => String(user?.role ?? "").toLowerCase() === "barber")
      .sort((a, b) => {
        const left = String(a?.displayName ?? a?.username ?? "");
        const right = String(b?.displayName ?? b?.username ?? "");
        return left.localeCompare(right, undefined, { sensitivity: "base" });
      });

    if (users.length === 0) {
      barberUsersList.innerHTML = `
        <section class="empty-state">
          <span class="empty-state-icon" aria-hidden="true">S</span>
          <h3>No barbers yet</h3>
          <p>Add barber accounts so clients can book specific team members.</p>
        </section>
      `;
      return;
    }

    barberUsersList.innerHTML = `
      <ul class="availability-timeoff-items">
        ${users.map((user) => `
          <li class="availability-timeoff-item">
            <div>
              <strong>${escapeHtml(String(user?.displayName ?? user?.username ?? ""))}</strong>
              <p class="small">@${escapeHtml(String(user?.username ?? ""))}</p>
            </div>
            <span class="badge badge-booked">Barber</span>
          </li>
        `).join("")}
      </ul>
    `;
  }

  function clampNumber(value, min, max, fallback) {
    const num = Number(value);
    if (!Number.isFinite(num)) return fallback;
    return Math.min(max, Math.max(min, Math.round(num)));
  }

  function toNonNegativeMoney(value) {
    const num = Number(value);
    if (!Number.isFinite(num)) return null;
    const normalized = Math.round(num * 100) / 100;
    return normalized >= 0 ? normalized : null;
  }

  function getDefaultBookingPolicy() {
    return {
      allowSameDay: true,
      maxDaysAdvance: 30,
      cancelHours: 24,
      bufferMinutes: 0,
      requireDeposit: false,
      depositAmount: 0,
      lateGraceMinutes: 10,
      noShowStrikeLimit: 2,
    };
  }

  function applyDepositToggleState() {
    if (!depositAmountInput) return;
    const enabled = Boolean(requireDepositInput?.checked);
    depositAmountInput.disabled = !enabled;
    if (!enabled) {
      depositAmountInput.value = "";
    }
  }

  function setProfileStatus(message, isSuccess) {
    if (!profileStatus) return;
    profileStatus.textContent = String(message ?? "");
    profileStatus.setAttribute("role", isSuccess ? "status" : "alert");
    profileStatus.setAttribute("aria-live", isSuccess ? "polite" : "assertive");
    profileStatus.setAttribute("aria-atomic", "true");
    profileStatus.classList.remove("status-success", "status-error");
    profileStatus.classList.add(isSuccess ? "status-success" : "status-error");
  }

  function clearProfileStatus() {
    if (!profileStatus) return;
    profileStatus.textContent = "";
    profileStatus.setAttribute("role", "status");
    profileStatus.setAttribute("aria-live", "polite");
    profileStatus.setAttribute("aria-atomic", "true");
    profileStatus.classList.remove("status-success", "status-error");
  }

  function setShopStatus(message, isSuccess) {
    if (!shopStatus) return;
    shopStatus.textContent = String(message ?? "");
    shopStatus.setAttribute("role", isSuccess ? "status" : "alert");
    shopStatus.setAttribute("aria-live", isSuccess ? "polite" : "assertive");
    shopStatus.setAttribute("aria-atomic", "true");
    shopStatus.classList.remove("status-success", "status-error");
    shopStatus.classList.add(isSuccess ? "status-success" : "status-error");
  }

  function clearShopStatus() {
    if (!shopStatus) return;
    shopStatus.textContent = "";
    shopStatus.setAttribute("role", "status");
    shopStatus.setAttribute("aria-live", "polite");
    shopStatus.setAttribute("aria-atomic", "true");
    shopStatus.classList.remove("status-success", "status-error");
  }

  function setBarberUserStatus(message, isSuccess) {
    if (!barberUserStatus) return;
    barberUserStatus.textContent = String(message ?? "");
    barberUserStatus.setAttribute("role", isSuccess ? "status" : "alert");
    barberUserStatus.setAttribute("aria-live", isSuccess ? "polite" : "assertive");
    barberUserStatus.setAttribute("aria-atomic", "true");
    barberUserStatus.classList.remove("status-success", "status-error");
    barberUserStatus.classList.add(isSuccess ? "status-success" : "status-error");
  }

  function updatePublicBookingLink(shop) {
    if (!publicBookingLinkInput) return;
    clearPublicBookingLinkStatus();
    clearPublicBookingQrStatus();

    const slug = toSlug(shop?.slug ?? shop?.name ?? businessNameInput?.value ?? "");
    if (!slug) {
      publicBookingLinkInput.value = "";
      if (copyPublicBookingLinkBtn) copyPublicBookingLinkBtn.disabled = true;
      if (openPublicBookingLinkBtn) openPublicBookingLinkBtn.disabled = true;
      setPublicBookingQrUnavailable("QR code will appear once booking URL is available.");
      return;
    }

    publicBookingLinkInput.value = getPublicBookingUrl(slug);
    if (copyPublicBookingLinkBtn) copyPublicBookingLinkBtn.disabled = false;
    if (openPublicBookingLinkBtn) openPublicBookingLinkBtn.disabled = false;
    renderPublicBookingQr(publicBookingLinkInput.value);
  }

  function getPublicBookingUrl(slug) {
    const origin = String(window.location.origin ?? "").trim();
    const encodedSlug = encodeURIComponent(String(slug ?? "").trim());
    if (origin) {
      return `${origin}/pages/book.html?shop=${encodedSlug}`;
    }
    return `/pages/book.html?shop=${encodedSlug}`;
  }

  async function copyText(value) {
    const text = String(value ?? "");
    if (!text) return false;

    if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
      await navigator.clipboard.writeText(text);
      return true;
    }

    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "true");
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    textarea.style.top = "0";
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const copied = document.execCommand("copy");
    textarea.remove();
    return copied;
  }

  async function handleCopyPublicBookingLink() {
    const value = String(publicBookingLinkInput?.value ?? "").trim();
    if (!value) {
      setPublicBookingLinkStatus("Public booking link is not ready yet.", false);
      return;
    }

    try {
      const copied = await copyText(value);
      if (!copied) throw new Error("copy_failed");
      setPublicBookingLinkStatus("Booking link copied.", true);
      showToast?.("Booking link copied.", "success");
    } catch {
      setPublicBookingLinkStatus("Could not copy link. Please copy it manually.", false);
    }
  }

  function handleOpenPublicBookingLink() {
    const value = String(publicBookingLinkInput?.value ?? "").trim();
    if (!value) {
      setPublicBookingLinkStatus("Public booking link is not ready yet.", false);
      return;
    }
    window.open(value, "_blank", "noopener,noreferrer");
  }

  async function renderPublicBookingQr(bookingUrl) {
    const value = String(bookingUrl ?? "").trim();
    if (!value) {
      setPublicBookingQrUnavailable("QR code will appear once booking URL is available.");
      return;
    }

    if (!publicBookingQrImage) return;
    clearPublicBookingQrStatus();

    try {
      const qrLib = window.QRCode;
      if (!qrLib || typeof qrLib.toDataURL !== "function") {
        throw new Error("qr_library_unavailable");
      }

      const dataUrl = await qrLib.toDataURL(value, {
        margin: 1,
        width: 320,
        color: {
          dark: "#0f172a",
          light: "#ffffff",
        },
      });

      publicBookingQrDataUrl = String(dataUrl ?? "").trim();
      if (!publicBookingQrDataUrl) throw new Error("qr_generation_failed");

      publicBookingQrImage.src = publicBookingQrDataUrl;
      publicBookingQrImage.classList.remove("hidden");
      if (publicBookingQrEmpty) publicBookingQrEmpty.classList.add("hidden");
      if (downloadPublicBookingQrBtn) downloadPublicBookingQrBtn.disabled = false;
      if (printPublicBookingQrBtn) printPublicBookingQrBtn.disabled = false;
    } catch {
      setPublicBookingQrUnavailable("QR preview unavailable right now. You can still share the booking URL.");
      setPublicBookingQrStatus("Could not generate QR code.", false);
    }
  }

  function handleDownloadPublicBookingQr() {
    clearPublicBookingQrStatus();
    if (!publicBookingQrDataUrl) {
      setPublicBookingQrStatus("QR code is not ready to download.", false);
      return;
    }

    const slug = getBookingSlugFromUrl(String(publicBookingLinkInput?.value ?? ""));
    const filename = `slotzy-${slug || "shop"}-qr.png`;
    const anchor = document.createElement("a");
    anchor.href = publicBookingQrDataUrl;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setPublicBookingQrStatus("QR code downloaded.", true);
  }

  function handlePrintPublicBookingQr() {
    clearPublicBookingQrStatus();
    if (!publicBookingQrDataUrl) {
      setPublicBookingQrStatus("QR code is not ready to print.", false);
      return;
    }

    const bookingUrl = String(publicBookingLinkInput?.value ?? "").trim();
    const businessName = String(businessNameInput?.value ?? "").trim() || "Slotzy Shop";
    const printWindow = window.open("", "_blank", "noopener,noreferrer,width=540,height=720");
    if (!printWindow) {
      setPublicBookingQrStatus("Popup blocked. Allow popups to print QR.", false);
      return;
    }

    const title = `${businessName} Booking QR`;
    const safeTitle = escapeHtml(title);
    const safeUrl = escapeHtml(bookingUrl);
    printWindow.document.open();
    printWindow.document.write(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>${safeTitle}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; text-align: center; color: #0f172a; }
    h1 { margin: 0 0 8px; font-size: 24px; }
    p { margin: 0 0 10px; font-size: 14px; color: #334155; }
    .qr-wrap { display: inline-block; border: 1px solid #cbd5e1; border-radius: 12px; padding: 12px; background: #ffffff; }
    img { width: 260px; height: 260px; display: block; }
    .link { margin-top: 12px; word-break: break-all; font-size: 12px; color: #334155; }
  </style>
</head>
<body>
  <h1>${safeTitle}</h1>
  <p>Scan to book</p>
  <div class="qr-wrap">
    <img src="${publicBookingQrDataUrl}" alt="Booking QR code" />
  </div>
  <p class="link">${safeUrl}</p>
</body>
</html>`);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  }

  function setPublicBookingQrUnavailable(message) {
    publicBookingQrDataUrl = "";
    if (publicBookingQrImage) {
      publicBookingQrImage.removeAttribute("src");
      publicBookingQrImage.classList.add("hidden");
    }
    if (publicBookingQrEmpty) {
      publicBookingQrEmpty.textContent = String(message ?? "QR code is unavailable.");
      publicBookingQrEmpty.classList.remove("hidden");
    }
    if (downloadPublicBookingQrBtn) downloadPublicBookingQrBtn.disabled = true;
    if (printPublicBookingQrBtn) printPublicBookingQrBtn.disabled = true;
  }

  function getBookingSlugFromUrl(urlText) {
    const raw = String(urlText ?? "").trim();
    if (!raw) return "";
    try {
      const parsed = new URL(raw, window.location.origin);
      return String(parsed.searchParams.get("shop") ?? "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9_-]+/g, "-")
        .replace(/^-+|-+$/g, "");
    } catch {
      return "";
    }
  }

  function setPublicBookingQrStatus(message, isSuccess) {
    if (!publicBookingQrStatus) return;
    publicBookingQrStatus.textContent = String(message ?? "");
    publicBookingQrStatus.setAttribute("role", isSuccess ? "status" : "alert");
    publicBookingQrStatus.setAttribute("aria-live", isSuccess ? "polite" : "assertive");
    publicBookingQrStatus.setAttribute("aria-atomic", "true");
    publicBookingQrStatus.classList.remove("status-success", "status-error");
    publicBookingQrStatus.classList.add(isSuccess ? "status-success" : "status-error");
  }

  function clearPublicBookingQrStatus() {
    if (!publicBookingQrStatus) return;
    publicBookingQrStatus.textContent = "";
    publicBookingQrStatus.setAttribute("role", "status");
    publicBookingQrStatus.setAttribute("aria-live", "polite");
    publicBookingQrStatus.setAttribute("aria-atomic", "true");
    publicBookingQrStatus.classList.remove("status-success", "status-error");
  }

  function setPublicBookingLinkStatus(message, isSuccess) {
    if (!publicBookingLinkStatus) return;
    publicBookingLinkStatus.textContent = String(message ?? "");
    publicBookingLinkStatus.setAttribute("role", isSuccess ? "status" : "alert");
    publicBookingLinkStatus.setAttribute("aria-live", isSuccess ? "polite" : "assertive");
    publicBookingLinkStatus.setAttribute("aria-atomic", "true");
    publicBookingLinkStatus.classList.remove("status-success", "status-error");
    publicBookingLinkStatus.classList.add(isSuccess ? "status-success" : "status-error");
  }

  function clearPublicBookingLinkStatus() {
    if (!publicBookingLinkStatus) return;
    publicBookingLinkStatus.textContent = "";
    publicBookingLinkStatus.setAttribute("role", "status");
    publicBookingLinkStatus.setAttribute("aria-live", "polite");
    publicBookingLinkStatus.setAttribute("aria-atomic", "true");
    publicBookingLinkStatus.classList.remove("status-success", "status-error");
  }

  function clearBarberUserStatus() {
    if (!barberUserStatus) return;
    barberUserStatus.textContent = "";
    barberUserStatus.setAttribute("role", "status");
    barberUserStatus.setAttribute("aria-live", "polite");
    barberUserStatus.setAttribute("aria-atomic", "true");
    barberUserStatus.classList.remove("status-success", "status-error");
  }

  function setDemoStatus(message, isSuccess) {
    if (!demoStatus) return;
    demoStatus.textContent = String(message ?? "");
    demoStatus.setAttribute("role", isSuccess ? "status" : "alert");
    demoStatus.setAttribute("aria-live", isSuccess ? "polite" : "assertive");
    demoStatus.setAttribute("aria-atomic", "true");
    demoStatus.classList.remove("status-success", "status-error");
    demoStatus.classList.add(isSuccess ? "status-success" : "status-error");
  }

  function clearDemoStatus() {
    if (!demoStatus) return;
    demoStatus.textContent = "";
    demoStatus.setAttribute("role", "status");
    demoStatus.setAttribute("aria-live", "polite");
    demoStatus.setAttribute("aria-atomic", "true");
    demoStatus.classList.remove("status-success", "status-error");
  }

  function notifyProfileSaved() {
    if (typeof showToast === "function") {
      showToast("Your profile has been updated.", "success");
      return;
    }
    showFallbackToast("Your profile has been updated.");
  }

  function showFallbackToast(message) {
    let toast = document.getElementById("toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "toast";
      toast.className = "toast hidden";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.remove("hidden");
    toast.classList.add("toast-success");
    window.setTimeout(() => {
      toast.classList.add("hidden");
      toast.classList.remove("toast-success");
    }, 2500);
  }

  function applySavedButtonFeedback() {
    if (!saveProfileBtn) return;
    if (saveFeedbackTimer) {
      clearTimeout(saveFeedbackTimer);
      saveFeedbackTimer = null;
    }

    const originalText = "Save Profile";
    saveProfileBtn.disabled = true;
    saveProfileBtn.textContent = "Saved";
    saveFeedbackTimer = window.setTimeout(() => {
      saveProfileBtn.textContent = originalText;
      saveProfileBtn.disabled = false;
      saveFeedbackTimer = null;
    }, 1400);
  }

  function bindCompletenessEvents() {
    [fullNameInput, emailInput, phoneInput].forEach((input) => {
      input?.addEventListener("keyup", updateProfileCompleteness);
      input?.addEventListener("change", updateProfileCompleteness);
    });
  }

  function updateProfileCompleteness() {
    const fullName = String(fullNameInput?.value ?? "").trim();
    const email = String(emailInput?.value ?? "").trim();
    const phone = String(phoneInput?.value ?? "").trim();

    const fields = [
      { label: "full name", filled: Boolean(fullName) },
      { label: "email", filled: Boolean(email) },
      { label: "phone", filled: Boolean(phone) },
    ];
    const filledCount = fields.filter((field) => field.filled).length;
    const percent = Math.round((filledCount / 3) * 100);
    const missing = fields.filter((field) => !field.filled).map((field) => field.label);

    if (profileCompletenessText) {
      profileCompletenessText.textContent = `Profile completeness: ${percent}%`;
    }
    if (profileProgressBar) {
      profileProgressBar.style.width = `${percent}%`;
    }
    if (missingFields) {
      missingFields.textContent = missing.length > 0
        ? `Missing: ${missing.join(", ")}`
        : "Missing: none";
    }
  }

  function renderLoggedOutState() {
    if (!settingsMain) return;
    settingsMain.innerHTML = `
      <section class="card owner-panel" style="max-width: 560px; margin: 2rem auto; text-align: center;">
        <h1>Please sign in to access settings.</h1>
        <p class="small">Sign in with your account to update your profile.</p>
        <a href="../index.html" class="btn btn-primary owner-action-btn">Go to Home</a>
      </section>
    `;
  }

  function createId(prefix) {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return `${prefix}_${window.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  }

  function toSlug(value) {
    return String(value ?? "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || `shop-${Date.now()}`;
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }
})();
