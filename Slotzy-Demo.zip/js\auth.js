import * as dataStore from "./dataStore.js";

const API_BASE = "http://localhost:3001";
const FRIENDLY_OFFLINE_ERROR = "Cannot reach the auth server. Start backend on http://localhost:3001 and try again.";

function normalizeRole(role) {
  const value = String(role ?? "").trim().toLowerCase();
  if (value === "owner" || value === "customer" || value === "barber") return value;
  return "customer";
}

function normalizeAuthUser(user) {
  if (!user || typeof user !== "object") return null;
  const username = String(user.username ?? "").trim();
  if (!username) return null;
  return {
    username,
    role: normalizeRole(user.role),
  };
}

function syncAuthUserToLocalUsers(authUser) {
  const normalizedUser = normalizeAuthUser(authUser);
  if (!normalizedUser) return;

  const users = dataStore.getUsers();
  const matchIndex = users.findIndex(
    (candidate) => String(candidate?.username ?? "").toLowerCase() === normalizedUser.username.toLowerCase()
  );
  const current = matchIndex >= 0 ? users[matchIndex] : {};

  const shops = dataStore.getShops();
  const fallbackShopId = String(shops[0]?.id ?? "").trim();
  const role = normalizeRole(normalizedUser.role);
  const next = {
    ...current,
    username: normalizedUser.username,
    role,
    displayName: String(current?.displayName ?? normalizedUser.username).trim() || normalizedUser.username,
  };

  if (role === "owner" || role === "barber") {
    const shopId = String(current?.shopId ?? fallbackShopId).trim();
    if (shopId) next.shopId = shopId;
  } else {
    next.shopId = null;
  }

  if (matchIndex >= 0) users[matchIndex] = next;
  else users.push(next);

  dataStore.saveUsers(users);
}

function getErrorMessage(payload, fallback) {
  if (payload && typeof payload.error === "string" && payload.error.trim()) {
    return payload.error.trim();
  }
  if (payload && typeof payload.message === "string" && payload.message.trim()) {
    return payload.message.trim();
  }
  return fallback;
}

async function requestJson(path, { method = "GET", token = "", body } = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
  } catch {
    throw new Error(FRIENDLY_OFFLINE_ERROR);
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok) {
    throw new Error(getErrorMessage(payload, "Unable to complete authentication right now."));
  }

  return payload ?? {};
}

async function submitAuth({ username, password, role, isRegister }) {
  const path = isRegister ? "/api/auth/register" : "/api/auth/login";
  const payload = isRegister
    ? { username, password, role: normalizeRole(role) }
    : { username, password };

  const response = await requestJson(path, {
    method: "POST",
    body: payload,
  });

  const token = String(response?.token ?? "").trim();
  const authUser = normalizeAuthUser(response?.user);
  if (!token || !authUser) {
    throw new Error("Auth response was missing required fields.");
  }

  dataStore.setAuthToken(token);
  syncAuthUserToLocalUsers(authUser);
  return authUser;
}

export async function restoreSessionFromApi({ setUser, clearUser } = {}) {
  const token = dataStore.getAuthToken();
  if (!token) {
    if (typeof clearUser === "function") clearUser();
    return { restored: false, reason: "missing_token" };
  }

  try {
    const response = await requestJson("/api/auth/me", {
      method: "GET",
      token,
    });
    const authUser = normalizeAuthUser(response?.user);
    if (!authUser) {
      dataStore.clearAuthToken();
      if (typeof clearUser === "function") clearUser();
      return { restored: false, reason: "invalid_user" };
    }

    syncAuthUserToLocalUsers(authUser);
    if (typeof setUser === "function") setUser(authUser);
    return { restored: true, user: authUser };
  } catch (error) {
    const message = String(error?.message ?? "").trim();
    const offline = message === FRIENDLY_OFFLINE_ERROR;
    if (!offline) {
      dataStore.clearAuthToken();
      if (typeof clearUser === "function") clearUser();
      return { restored: false, reason: "invalid_token", error: message };
    }
    return { restored: false, reason: "offline", error: message };
  }
}

export function createAuthUi({
  modalPanel,
  showModal,
  hideModal,
  setUser,
  goToDashboard,
}) {
  function openAuthModal() {
    modalPanel.innerHTML = `
      <h2 id="modal-title">Login</h2>
      <div class="modal-toggle">
        <button type="button" id="show-login" class="btn btn-ghost active" aria-pressed="true">Login</button>
        <button type="button" id="show-register" class="btn btn-ghost" aria-pressed="false">Register</button>
      </div>

      <form id="auth-form" aria-describedby="auth-error" novalidate>
        <label for="auth-username">Username</label>
        <input type="text" id="auth-username" autocomplete="username" required />

        <label for="auth-password">Password</label>
        <input type="password" id="auth-password" autocomplete="current-password" required />

        <div id="role-wrap" class="hidden" aria-hidden="true">
          <label for="auth-role">Role</label>
          <select id="auth-role">
            <option value="customer">Customer</option>
            <option value="owner">Business Owner</option>
            <option value="barber">Barber</option>
          </select>
        </div>

        <button type="submit" class="btn btn-primary" id="submit-btn">Continue</button>
        <button type="button" class="btn btn-ghost" id="close-modal">Close</button>
        <div id="auth-error" class="small auth-error hidden" role="alert" aria-live="assertive" aria-atomic="true"></div>
      </form>
    `;

    showModal();
    document.getElementById("auth-username")?.focus();

    const showLoginBtn = document.getElementById("show-login");
    const showRegisterBtn = document.getElementById("show-register");
    const roleWrap = document.getElementById("role-wrap");
    const modalTitle = document.getElementById("modal-title");
    const authError = document.getElementById("auth-error");
    const submitBtn = document.getElementById("submit-btn");

    function setAuthError(message) {
      if (!authError) return;
      const text = String(message ?? "").trim();
      authError.textContent = text;
      authError.classList.toggle("hidden", !text);
    }

    function setMode(mode) {
      const isRegister = mode === "register";
      modalTitle.textContent = isRegister ? "Register" : "Login";
      roleWrap.classList.toggle("hidden", !isRegister);
      roleWrap.setAttribute("aria-hidden", isRegister ? "false" : "true");
      showLoginBtn.classList.toggle("active", !isRegister);
      showRegisterBtn.classList.toggle("active", isRegister);
      showLoginBtn.setAttribute("aria-pressed", isRegister ? "false" : "true");
      showRegisterBtn.setAttribute("aria-pressed", isRegister ? "true" : "false");
      setAuthError("");
    }

    showLoginBtn.addEventListener("click", () => setMode("login"));
    showRegisterBtn.addEventListener("click", () => setMode("register"));

    document.getElementById("close-modal")?.addEventListener("click", hideModal);

    document.getElementById("auth-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      setAuthError("");

      const username = document.getElementById("auth-username").value.trim();
      const password = document.getElementById("auth-password").value.trim();
      const role = document.getElementById("auth-role").value;
      const isRegister = showRegisterBtn.classList.contains("active");

      if (!username || !password) {
        setAuthError("Enter both username and password.");
        return;
      }

      if (submitBtn) submitBtn.disabled = true;
      try {
        const authUser = await submitAuth({
          username,
          password,
          role,
          isRegister,
        });
        setUser(authUser);
        hideModal();
        goToDashboard();
      } catch (error) {
        setAuthError(error?.message || "Unable to sign in right now.");
      } finally {
        if (submitBtn) submitBtn.disabled = false;
      }
    });
  }

  return { openAuthModal };
}
