import { wireLogoutButton } from "./logout.js";
import * as dataStore from "./dataStore.js";

(function () {
  const CLIENT_SESSION_KEY = "Slotzy_clientSession";
  const LAST_BOOKING_KEY = "Slotzy_lastBookingId";
  const SLOT_INCREMENT_MINUTES = 15;
  const DAY_KEYS = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const BOOKING_SYNC_EVENT = "slotzy:bookings-updated";
  const BOOKINGS_STORAGE_KEY = dataStore.KEYS?.BOOKINGS || "Slotzy_bookings";
  const DEMO_CANCELLATION_WINDOW_HOURS = 2;

  const dashboardMain = document.querySelector("main.owner-layout");
  const bookingPanel = document.getElementById("bookingPanel");
  const shopSelect = document.getElementById("shopSelect");
  const barberSelect = document.getElementById("barberSelect");
  const serviceSelect = document.getElementById("serviceSelect");
  const bookingDate = document.getElementById("bookingDate");
  const slotList = document.getElementById("slotList");
  const clientNameInput = document.getElementById("clientName");
  const clientContactInput = document.getElementById("clientContact");
  const depositNotice = document.getElementById("depositNotice");
  const depositNoticeText = document.getElementById("depositNoticeText");
  const depositAckWrap = document.getElementById("depositAckWrap");
  const depositAcknowledge = document.getElementById("depositAcknowledge");
  const bookBtn = document.getElementById("bookBtn");
  const policyHint = document.getElementById("policyHint");
  const bookingStatus = document.getElementById("bookingStatus");
  const nextAppointmentDetails = document.getElementById("nextAppointmentDetails");
  const nextAppointmentService = document.getElementById("nextAppointmentService");
  const nextAppointmentDate = document.getElementById("nextAppointmentDate");
  const nextAppointmentTime = document.getElementById("nextAppointmentTime");
  const nextAppointmentStatus = document.getElementById("nextAppointmentStatus");
  const nextAppointmentEmptyState = document.getElementById("nextAppointmentEmptyState");
  const upcomingList = document.getElementById("upcomingList");
  const upcomingEmptyState = document.getElementById("upcomingEmptyState");
  const pastList = document.getElementById("pastList");
  const pastEmptyState = document.getElementById("pastEmptyState");
  const publicShopName = document.getElementById("publicShopName");
  const publicShopBranding = document.getElementById("publicShopBranding");
  const publicShopError = document.getElementById("publicShopError");
  const publicShopLogo = document.getElementById("publicShopLogo");
  const showToast = window.showToast;
  const isPublicBookingPage = /\/(?:book|book-shop)\.html$/i.test(window.location.pathname);
  const requestedShopSlug = normalizeSlug(new URLSearchParams(window.location.search).get("shop"));

  const currentUser = dataStore.getSessionUser();
  const currentUsername = String(currentUser?.username ?? "").trim();
  const isLoggedInCustomer = String(currentUser?.role ?? "").toLowerCase() === "customer" && Boolean(currentUsername);
  const initialClientSession = getClientSession();
  let activeClientIdentity = getActiveClientIdentity();
  let receiptSection = null;

  let selectedSlotValue = "";
  let selectedShopId = "";
  let selectedBarberUsername = "";
  let publicShopSlugError = "";
  let bookingSyncBound = false;

  wireLogoutButton({ redirectPath: "../index.html" });
  init();

  function init() {
    if (clientNameInput && !clientNameInput.value) {
      clientNameInput.value = String(initialClientSession?.clientName ?? currentUsername ?? "").trim();
    }
    if (clientContactInput && !clientContactInput.value) {
      clientContactInput.value = String(initialClientSession?.clientContact ?? "").trim();
    }
    populateShops();
    if (publicShopSlugError) {
      disableBookingFlow(publicShopSlugError);
      return;
    }
    populateBarbers();
    populateServices();
    initializeDate();
    updatePolicyHint();
    renderDepositPolicyNotice();
    renderSlots();
    renderClientAppointments();
    renderLastBookingPrompt();

    shopSelect?.addEventListener("change", () => {
      clearStatus();
      selectedShopId = String(shopSelect.value ?? "").trim();
      selectedBarberUsername = "";
      if (barberSelect) barberSelect.value = "";
      populateBarbers();
      populateServices();
      updatePolicyHint();
      renderDepositPolicyNotice();
      renderSlots();
    });
    barberSelect?.addEventListener("change", () => {
      clearStatus();
      selectedBarberUsername = String(barberSelect.value ?? "").trim();
      populateServices();
      updatePolicyHint();
      renderDepositPolicyNotice();
      renderSlots();
    });
    serviceSelect?.addEventListener("change", () => {
      clearStatus();
      renderDepositPolicyNotice();
      renderSlots();
    });
    bookingDate?.addEventListener("change", () => {
      clearStatus();
      renderSlots();
    });
    depositAcknowledge?.addEventListener("change", () => {
      clearStatus();
      updateBookButtonState();
    });
    bookBtn?.addEventListener("click", handleBook);
    bindBookingSyncListeners();
    updateBookButtonState();
  }

  function getLastBookingId() {
    return String(sessionStorage.getItem(LAST_BOOKING_KEY) ?? "").trim();
  }

  function setLastBookingId(id) {
    sessionStorage.setItem(LAST_BOOKING_KEY, String(id ?? "").trim());
  }

  function getBookingById(id) {
    const targetId = String(id ?? "").trim();
    if (!targetId) return null;
    return getBookings().find((booking) => String(booking?.id ?? "") === targetId) || null;
  }

  function renderLastBookingPrompt() {
    const existingRow = document.getElementById("last-booking-prompt");
    existingRow?.remove();
    if (!bookingStatus) return;
    if (!activeClientIdentity) return;

    const lastBooking = getBookingById(getLastBookingId());
    if (!lastBooking) return;
    if (!isBookingForActiveClient(lastBooking)) return;

    const row = document.createElement("div");
    row.id = "last-booking-prompt";
    row.className = "home-login-row";
    row.innerHTML = `
      <button type="button" class="btn btn-ghost" id="btn-view-last-booking">
        View last booking confirmation
      </button>
    `;
    bookingStatus.insertAdjacentElement("afterend", row);
    row.querySelector("#btn-view-last-booking")?.addEventListener("click", () => {
      renderBookingReceipt(lastBooking);
    });
  }

  function ensureReceiptSection() {
    if (!dashboardMain) return null;
    if (receiptSection && dashboardMain.contains(receiptSection)) return receiptSection;

    const section = document.createElement("section");
    section.id = "booking-receipt-section";
    section.className = "card owner-panel booking-receipt hidden";
    dashboardMain.appendChild(section);
    receiptSection = section;
    return section;
  }

  function toggleReceiptMode(showReceipt) {
    if (!dashboardMain) return;
    const section = ensureReceiptSection();
    if (!section) return;

    Array.from(dashboardMain.children).forEach((child) => {
      if (child === section) return;
      child.classList.toggle("hidden", showReceipt);
    });
    section.classList.toggle("hidden", !showReceipt);
  }

  function renderBookingReceipt(booking) {
    const section = ensureReceiptSection();
    if (!section) return;

    const start = getBookingStartDate(booking);
    const end = getBookingEndDate(booking);
    const durationMinutes = Number(booking?.durationMinutes ?? 0);
    const price = Number(booking?.price ?? 0);
    const confirmationId = getConfirmationCode(String(booking?.id ?? ""));
    const depositDetails = getBookingDepositDetails(booking);
    const status = normalizeAppointmentStatus(booking?.status);
    const cancellation = getBookingCancellationState(booking);
    const canShowManageActions = isScheduledStatus(status);
    const cancellationHint = getManageCancellationHint(booking, cancellation);
    section.dataset.bookingId = String(booking?.id ?? "").trim();

    section.innerHTML = `
      <h1>Booking Confirmed</h1>
      <p class="lead">Your appointment has been saved.</p>

      <div class="booking-receipt-grid">
        <p><strong>Service:</strong> ${escapeHtml(String(booking?.serviceName ?? "Service"))}</p>
        <p><strong>Date:</strong> ${escapeHtml(start ? formatDateFriendly(start) : "")}</p>
        <p><strong>Time:</strong> ${escapeHtml(start ? formatDateLocalTime(start) : "")}${end ? ` - ${escapeHtml(formatDateLocalTime(end))}` : ""}</p>
        <p><strong>Duration:</strong> ${escapeHtml(`${durationMinutes} minutes`)}</p>
        <p><strong>Price:</strong> ${escapeHtml(`$${price.toFixed(2)}`)}</p>
        <p><strong>Shop:</strong> ${escapeHtml(getBookingShopLabel(booking) || "N/A")}</p>
        <p><strong>Barber:</strong> ${escapeHtml(getBookingBarberLabel(booking) || "N/A")}</p>
        <p><strong>Client:</strong> ${escapeHtml(String(booking?.clientName ?? ""))}</p>
        <p><strong>Contact:</strong> ${escapeHtml(String(booking?.clientContact ?? ""))}</p>
        <p><strong>Deposit:</strong> ${escapeHtml(depositDetails.required ? `$${depositDetails.amount.toFixed(2)} required` : "Not required")}</p>
        <p><strong>Deposit Status:</strong> ${escapeHtml(formatDepositStatusLabel(depositDetails.status))}</p>
        <p><strong>Status:</strong> ${escapeHtml(getAppointmentStatusLabel(status))}</p>
        <p><strong>Confirmation Code:</strong> ${escapeHtml(confirmationId)}</p>
      </div>

      <h2>Manage Appointment</h2>
      <p class="small muted">${escapeHtml(cancellationHint)}</p>
      <p id="booking-receipt-error" class="small booking-status" aria-live="polite"></p>
      <div class="booking-receipt-actions">
        ${canShowManageActions
          ? `<button type="button" class="btn btn-ghost" id="btn-receipt-calendar">Add to Calendar</button>`
          : ""}
        ${canShowManageActions
          ? `<button type="button" class="btn btn-ghost" id="btn-receipt-cancel" ${cancellation.canCancel ? "" : "disabled"}>Cancel Appointment</button>`
          : ""}
        <button type="button" class="btn btn-primary" id="btn-book-another">Book Another</button>
      </div>
    `;

    toggleReceiptMode(true);
    clearReceiptError();
    section.querySelector("#btn-book-another")?.addEventListener("click", () => {
      toggleReceiptMode(false);
      clearStatus();
      selectedSlotValue = "";
      updateBookButtonState();
      if (serviceSelect) serviceSelect.value = "";
      if (bookingDate) bookingDate.value = toYmd(new Date());
      renderSlots();
      serviceSelect?.focus();
    });
    section.querySelector("#btn-receipt-calendar")?.addEventListener("click", () => {
      clearReceiptError();
      const errorMessage = downloadIcs(booking);
      if (errorMessage) setReceiptError(errorMessage);
    });
    section.querySelector("#btn-receipt-cancel")?.addEventListener("click", () => {
      clearReceiptError();
      const result = cancelBookingById(String(booking?.id ?? ""), { confirmPrompt: true });
      if (!result.ok) {
        if (!result.cancelledByUser) setReceiptError(result.message);
        return;
      }
      setStatus("Appointment cancelled.", true);
      showToast?.("Appointment cancelled.", "success");
      renderSlots();
      renderClientAppointments();
      renderLastBookingPrompt();
      if (result.booking) {
        renderBookingReceipt(result.booking);
        setReceiptSuccess("Appointment cancelled.");
      }
    });
  }

  function getConfirmationCode(rawId) {
    const cleaned = String(rawId ?? "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    if (!cleaned) return "N/A";
    return cleaned.slice(-6);
  }

  function getReceiptErrorElement() {
    return document.getElementById("booking-receipt-error");
  }

  function setReceiptStatus(message, success) {
    const el = getReceiptErrorElement();
    if (!el) return;
    el.textContent = String(message ?? "").trim();
    el.setAttribute("role", success ? "status" : "alert");
    el.setAttribute("aria-live", success ? "polite" : "assertive");
    el.setAttribute("aria-atomic", "true");
    el.classList.remove("status-success", "status-error");
    el.classList.add(success ? "status-success" : "status-error");
  }

  function setReceiptError(message) {
    setReceiptStatus(message, false);
  }

  function setReceiptSuccess(message) {
    setReceiptStatus(message, true);
  }

  function clearReceiptError() {
    const el = getReceiptErrorElement();
    if (!el) return;
    el.textContent = "";
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");
    el.setAttribute("aria-atomic", "true");
    el.classList.remove("status-success", "status-error");
  }

  function generateIcsForBooking(booking) {
    const dtStamp = toIcsUtcStamp(new Date());
    const dtStart = toIcsUtcStamp(booking.startISO);
    const dtEnd = toIcsUtcStamp(booking.endISO);
    const price = Number(booking.price ?? 0);
    const priceText = Number.isFinite(price) ? price.toFixed(2) : "0.00";
    const barberLabel = getBookingBarberLabel(booking) || String(booking.ownerUsername ?? "");
    const shopLabel = getBookingShopLabel(booking) || "";
    const summary = escapeIcsText(`Slotzy - ${String(booking.serviceName ?? "")}`);
    const description = escapeIcsText(
      `Client: ${String(booking.clientName ?? "")} (${String(booking.clientContact ?? "")})\n` +
      `Barber: ${barberLabel}\n` +
      `Shop: ${shopLabel}\n` +
      `Price: $${priceText}`
    );

    const lines = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Slotzy//EN",
      "CALSCALE:GREGORIAN",
      "BEGIN:VEVENT",
      `UID:${String(booking.id ?? "")}@slotzy.local`,
      `DTSTAMP:${dtStamp}`,
      `DTSTART:${dtStart}`,
      `DTEND:${dtEnd}`,
      `SUMMARY:${summary}`,
      `DESCRIPTION:${description}`,
      "END:VEVENT",
      "END:VCALENDAR",
    ];

    return `${lines.join("\r\n")}\r\n`;
  }

  function downloadIcs(booking) {
    const errorMessage = validateCalendarBooking(booking);
    if (errorMessage) return errorMessage;

    const ics = generateIcsForBooking(booking);
    const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const startDate = new Date(booking.startISO);
    const datePart = toYmd(startDate);
    const servicePart = toFileSlug(String(booking.serviceName ?? "")) || "appointment";
    const filename = `slotzy-${datePart}-${servicePart}.ics`;

    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = "none";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    return null;
  }

  function validateCalendarBooking(booking) {
    if (!booking || typeof booking !== "object") return "Booking details are missing.";

    const status = normalizeAppointmentStatus(booking?.status);
    if (!isScheduledStatus(status)) return "Only booked or confirmed appointments can be added to your calendar.";

    const requiredFields = [
      { key: "id", label: "Booking ID" },
      { key: "serviceName", label: "Service name" },
      { key: "clientName", label: "Client name" },
      { key: "clientContact", label: "Client contact" },
      { key: "ownerUsername", label: "Barber" },
      { key: "startISO", label: "Start time" },
      { key: "endISO", label: "End time" },
    ];

    const missing = requiredFields.find(({ key }) => !String(booking[key] ?? "").trim());
    if (missing) return `${missing.label} is missing, so we cannot create a calendar file yet.`;

    const start = new Date(String(booking.startISO));
    const end = new Date(String(booking.endISO));
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || start >= end) {
      return "Booking time details are invalid. Please refresh and try again.";
    }
    return null;
  }

  function toIcsUtcStamp(value) {
    const date = value instanceof Date ? value : new Date(value);
    if (!Number.isFinite(date.getTime())) return "";
    const yyyy = String(date.getUTCFullYear());
    const mm = String(date.getUTCMonth() + 1).padStart(2, "0");
    const dd = String(date.getUTCDate()).padStart(2, "0");
    const hh = String(date.getUTCHours()).padStart(2, "0");
    const min = String(date.getUTCMinutes()).padStart(2, "0");
    const ss = String(date.getUTCSeconds()).padStart(2, "0");
    return `${yyyy}${mm}${dd}T${hh}${min}${ss}Z`;
  }

  function escapeIcsText(value) {
    return String(value ?? "")
      .replace(/\\/g, "\\\\")
      .replace(/\r?\n/g, "\\n")
      .replace(/,/g, "\\,")
      .replace(/;/g, "\\;");
  }

  function toFileSlug(value) {
    return String(value ?? "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  function getClientSession() {
    try {
      const parsed = JSON.parse(sessionStorage.getItem(CLIENT_SESSION_KEY) || "null");
      if (!parsed || typeof parsed !== "object") return null;
      const clientName = String(parsed.clientName ?? "").trim();
      const clientContact = String(parsed.clientContact ?? "").trim();
      if (!clientName || !clientContact) return null;
      return { clientName, clientContact };
    } catch {
      return null;
    }
  }

  function saveClientSession(clientName, clientContact) {
    const payload = {
      clientName: String(clientName ?? "").trim(),
      clientContact: String(clientContact ?? "").trim(),
    };
    sessionStorage.setItem(CLIENT_SESSION_KEY, JSON.stringify(payload));
  }

  function getActiveClientIdentity() {
    if (isLoggedInCustomer) {
      return {
        mode: "username",
        username: currentUsername,
      };
    }

    const stored = getClientSession();
    if (!stored) return null;
    return {
      mode: "session",
      clientName: stored.clientName,
      clientContact: stored.clientContact,
    };
  }

  function normalizeSlug(value) {
    return String(value ?? "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  function getPublicShopSlugError(shops) {
    if (!isPublicBookingPage) return "";
    if (!requestedShopSlug) {
      return "This booking link is missing a shop slug. Please check the URL and try again.";
    }
    const matched = shops.some((shop) => shop.slug === requestedShopSlug);
    if (!matched) {
      return `We could not find a shop for "${requestedShopSlug}". Please verify the booking link.`;
    }
    return "";
  }

  function updatePublicShopHeader(shop, errorMessage = "") {
    if (!isPublicBookingPage) return;

    if (publicShopName) {
      publicShopName.textContent = shop
        ? shop.name
        : "Shop not found";
    }
    if (publicShopBranding) {
      if (shop && shop.branding) {
        publicShopBranding.textContent = shop.branding;
      } else if (shop) {
        publicShopBranding.textContent = "Choose your barber, service, date, and time to book.";
      } else {
        publicShopBranding.textContent = "We could not load this shop's booking profile.";
      }
    }
    if (publicShopLogo) {
      const logoSrc = String(shop?.logoUrl ?? "").trim();
      if (logoSrc) {
        publicShopLogo.src = logoSrc;
        publicShopLogo.alt = `${shop?.name ?? "Shop"} logo`;
        publicShopLogo.classList.remove("hidden");
      } else {
        publicShopLogo.removeAttribute("src");
        publicShopLogo.classList.add("hidden");
      }
    }
    if (publicShopError) {
      const message = String(errorMessage ?? "").trim();
      publicShopError.textContent = message;
      publicShopError.classList.toggle("hidden", !message);
      publicShopError.classList.toggle("status-error", Boolean(message));
    }
  }

  function disableBookingFlow(message) {
    const disabled = true;
    [shopSelect, barberSelect, serviceSelect, bookingDate, clientNameInput, clientContactInput, depositAcknowledge, bookBtn]
      .forEach((field) => {
        if (!field) return;
        field.disabled = disabled;
      });

    if (slotList) {
      slotList.innerHTML = `
        <section class="empty-state">
          <span class="empty-state-icon" aria-hidden="true">S</span>
          <h3>Booking unavailable</h3>
          <p>${escapeHtml(String(message ?? "This booking link is currently unavailable."))}</p>
          <a class="btn btn-ghost empty-state-cta" href="../index.html">Back to home</a>
        </section>
      `;
    }

    selectedSlotValue = "";
    updateBookButtonState();
    setStatus(String(message ?? "This booking link is currently unavailable."), false);
  }

  function getShops() {
    return dataStore.getShops()
      .map((shop) => ({
        id: String(shop?.id ?? "").trim(),
        name: String(shop?.name ?? "Shop").trim() || "Shop",
        slug: normalizeSlug(shop?.slug ?? shop?.name ?? ""),
        branding: String(shop?.tagline ?? shop?.description ?? "").trim(),
        logoUrl: String(shop?.logoUrl ?? shop?.logo ?? "").trim(),
      }))
      .filter((shop) => Boolean(shop.id))
      .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
  }

  function populateShops() {
    if (!shopSelect) return;

    const shops = getShops();
    if (isPublicBookingPage) {
      publicShopSlugError = getPublicShopSlugError(shops);
      if (publicShopSlugError) {
        selectedShopId = "";
        shopSelect.innerHTML = '<option value="">Shop not found</option>';
        shopSelect.disabled = true;
        updatePublicShopHeader(null, publicShopSlugError);
        return;
      }

      const matchedShop = shops.find((shop) => shop.slug === requestedShopSlug) || null;
      if (!matchedShop) {
        selectedShopId = "";
        publicShopSlugError = "Shop not found.";
        shopSelect.innerHTML = '<option value="">Shop not found</option>';
        shopSelect.disabled = true;
        updatePublicShopHeader(null, publicShopSlugError);
        return;
      }

      publicShopSlugError = "";
      selectedShopId = matchedShop.id;
      shopSelect.innerHTML = `<option value="${escapeHtml(matchedShop.id)}">${escapeHtml(matchedShop.name)}</option>`;
      shopSelect.value = matchedShop.id;
      shopSelect.disabled = true;
      updatePublicShopHeader(matchedShop, "");
      return;
    }

    if (shops.length === 0) {
      selectedShopId = "";
      shopSelect.innerHTML = '<option value="">No shops available</option>';
      shopSelect.disabled = true;
      return;
    }

    const existing = shops.find((shop) => shop.id === selectedShopId);
    if (existing) {
      selectedShopId = existing.id;
    } else if (shops.length === 1) {
      selectedShopId = shops[0].id;
    } else {
      selectedShopId = "";
    }

    const defaultOption = shops.length > 1
      ? '<option value="">Select a shop</option>'
      : "";
    const optionsMarkup = shops.map((shop) => (
      `<option value="${escapeHtml(shop.id)}">${escapeHtml(shop.name)}</option>`
    )).join("");
    shopSelect.innerHTML = `${defaultOption}${optionsMarkup}`;

    if (selectedShopId) {
      shopSelect.value = selectedShopId;
    }
    shopSelect.disabled = shops.length <= 1;
  }

  function getBarbersForSelectedShop() {
    if (!selectedShopId) return [];
    return dataStore.getBarbersForShop(selectedShopId, { includeOwners: true })
      .map((barber) => ({
        username: String(barber?.username ?? "").trim(),
        displayName: String(barber?.displayName ?? barber?.username ?? "").trim() || String(barber?.username ?? ""),
      }))
      .filter((barber) => Boolean(barber.username));
  }

  function populateBarbers() {
    if (!barberSelect) return;

    if (!selectedShopId) {
      selectedBarberUsername = "";
      barberSelect.innerHTML = '<option value="">Select a shop first</option>';
      barberSelect.disabled = true;
      return;
    }

    const barbers = getBarbersForSelectedShop();
    if (barbers.length === 0) {
      selectedBarberUsername = "";
      barberSelect.innerHTML = '<option value="">No barbers available</option>';
      barberSelect.disabled = true;
      return;
    }

    const existing = barbers.find((barber) => barber.username === selectedBarberUsername);
    if (existing) {
      selectedBarberUsername = existing.username;
    } else if (barbers.length === 1) {
      selectedBarberUsername = barbers[0].username;
    } else {
      selectedBarberUsername = "";
    }

    const defaultOption = barbers.length > 1
      ? '<option value="">Select a barber</option>'
      : "";
    const optionsMarkup = barbers.map((barber) => (
      `<option value="${escapeHtml(barber.username)}">${escapeHtml(barber.displayName)}</option>`
    )).join("");
    barberSelect.innerHTML = `${defaultOption}${optionsMarkup}`;
    barberSelect.disabled = false;

    if (selectedBarberUsername) {
      barberSelect.value = selectedBarberUsername;
    }
  }

  function getSelectedShop() {
    const shopId = selectedShopId || String(shopSelect?.value ?? "").trim();
    if (!shopId) return null;
    return getShops().find((shop) => shop.id === shopId) || null;
  }

  function getSelectedBarber() {
    const username = selectedBarberUsername || String(barberSelect?.value ?? "").trim();
    if (!username) return null;
    return getBarbersForSelectedShop().find((barber) => barber.username === username) || null;
  }

  function resolveBarberDisplayName(username) {
    const target = String(username ?? "").trim();
    if (!target) return "";

    const fromShop = getBarbersForSelectedShop().find((barber) => barber.username === target);
    if (fromShop) return fromShop.displayName;

    const user = dataStore.getUsers().find((item) => String(item?.username ?? "") === target);
    return String(user?.displayName ?? user?.username ?? target).trim() || target;
  }

  function updatePolicyHint() {
    if (!policyHint) return;

    if (!selectedShopId) {
      policyHint.textContent = "Choose a shop to continue.";
      return;
    }
    if (!selectedBarberUsername) {
      policyHint.textContent = "Choose a barber to load services and available time slots.";
      return;
    }

    const barberLabel = resolveBarberDisplayName(selectedBarberUsername) || selectedBarberUsername;
    const depositPolicy = getActiveDepositPolicy();
    const depositText = depositPolicy.requireDeposit
      ? ` A deposit of $${depositPolicy.depositAmount.toFixed(2)} is required to book.`
      : " No deposit is required.";
    policyHint.textContent = `Slots are generated from ${barberLabel}'s availability, time off, and existing scheduled appointments.${depositText}`;
  }

  function getDefaultBookingPolicy() {
    return {
      requireDeposit: false,
      depositAmount: 0,
    };
  }

  function getShopBookingPolicy(shopId) {
    const defaults = getDefaultBookingPolicy();
    const legacyShop = dataStore.getShop();
    if (!legacyShop || typeof legacyShop !== "object") return defaults;

    const legacyShopId = String(legacyShop?.shopId ?? "").trim();
    const selectedId = String(shopId ?? "").trim();
    if (legacyShopId && selectedId && legacyShopId !== selectedId) return defaults;

    const policy = legacyShop?.bookingPolicy && typeof legacyShop.bookingPolicy === "object"
      ? legacyShop.bookingPolicy
      : {};
    const requireDeposit = Boolean(policy.requireDeposit);
    const amountRaw = Number(policy.depositAmount ?? 0);
    const depositAmount = Number.isFinite(amountRaw) && amountRaw > 0
      ? Number(amountRaw.toFixed(2))
      : 0;

    return {
      requireDeposit: requireDeposit && depositAmount > 0,
      depositAmount,
    };
  }

  function getActiveDepositPolicy() {
    const shop = getSelectedShop();
    const shopId = String(shop?.id ?? "").trim();
    return getShopBookingPolicy(shopId);
  }

  function renderDepositPolicyNotice() {
    if (!depositNotice || !depositNoticeText || !depositAckWrap || !depositAcknowledge) return;

    const policy = getActiveDepositPolicy();
    if (!selectedShopId) {
      depositNotice.classList.add("hidden");
      depositAckWrap.classList.add("hidden");
      depositAcknowledge.checked = false;
      updateBookButtonState();
      return;
    }

    depositNotice.classList.remove("hidden");
    if (!policy.requireDeposit) {
      depositNoticeText.textContent = "No deposit required for this shop.";
      depositAckWrap.classList.add("hidden");
      depositAcknowledge.checked = false;
      updateBookButtonState();
      return;
    }

    depositNoticeText.textContent = `A $${policy.depositAmount.toFixed(2)} deposit is required to hold this booking.`;
    depositAckWrap.classList.remove("hidden");
    updateBookButtonState();
  }

  function isDepositAcknowledgementRequired() {
    const policy = getActiveDepositPolicy();
    if (!policy.requireDeposit) return false;
    return !(depositAcknowledge?.checked ?? false);
  }

  function getServices() {
    if (!selectedShopId || !selectedBarberUsername) return [];

    return dataStore.getServices()
      .map(normalizeService)
      .filter((service) => service.active !== false)
      .filter((service) => String(service?.shopId ?? "") === selectedShopId)
      .filter((service) => {
        const barberUsername = String(service?.barberUsername ?? service?.ownerUsername ?? "").trim();
        return barberUsername === selectedBarberUsername;
      })
      .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
  }

  function getBookings() {
    return dataStore.getBookings();
  }

  function saveBookings(bookings) {
    dataStore.saveBookings(bookings);
  }

  function bindBookingSyncListeners() {
    if (bookingSyncBound) return;
    window.addEventListener("storage", handleStorageBookingSync);
    window.addEventListener(BOOKING_SYNC_EVENT, handleLocalBookingSync);
    bookingSyncBound = true;
  }

  function handleStorageBookingSync(event) {
    if (!event || (event.key && event.key !== BOOKINGS_STORAGE_KEY)) return;
    refreshAfterExternalBookingUpdate();
  }

  function handleLocalBookingSync() {
    refreshAfterExternalBookingUpdate();
  }

  function refreshAfterExternalBookingUpdate() {
    renderSlots();
    renderClientAppointments();
    renderLastBookingPrompt();

    if (!receiptSection || receiptSection.classList.contains("hidden")) return;
    const bookingId = String(receiptSection.dataset.bookingId ?? "").trim();
    if (!bookingId) return;
    const latest = getBookingById(bookingId);
    if (!latest || !isBookingForActiveClient(latest)) return;
    renderBookingReceipt(latest);
  }

  function normalizeService(service) {
    const name = String(service?.name ?? service?.title ?? "").trim() || "Service";
    const duration = Number(service?.durationMinutes ?? service?.duration ?? 0);
    const price = Number(service?.price ?? 0);
    return {
      ...service,
      id: String(service?.id ?? ""),
      name,
      durationMinutes: Number.isFinite(duration) ? Math.max(1, Math.round(duration)) : 30,
      price: Number.isFinite(price) ? Number(price.toFixed(2)) : 0,
    };
  }

  function populateServices() {
    if (!serviceSelect) return;

    if (!selectedShopId || !selectedBarberUsername) {
      serviceSelect.innerHTML = '<option value="">Select shop and barber first</option>';
      serviceSelect.disabled = true;
      return;
    }

    const services = getServices();
    if (services.length === 0) {
      serviceSelect.innerHTML = '<option value="">No services for this barber</option>';
      serviceSelect.disabled = true;
      return;
    }

    serviceSelect.innerHTML = '<option value="">Select a service</option>';
    serviceSelect.disabled = false;

    services.forEach((service) => {
      const option = document.createElement("option");
      option.value = service.id;
      option.textContent = `${service.name} - $${service.price.toFixed(2)} - ${service.durationMinutes} min`;
      option.dataset.serviceName = service.name;
      option.dataset.durationMinutes = String(service.durationMinutes);
      option.dataset.price = String(service.price);
      serviceSelect.appendChild(option);
    });
  }

  function initializeDate() {
    if (!bookingDate) return;
    bookingDate.min = toYmd(new Date());
    if (!bookingDate.value) bookingDate.value = toYmd(new Date());
  }

  function getSelectedService() {
    const serviceId = String(serviceSelect?.value ?? "");
    if (!serviceId) return null;
    return getServices().find((service) => service.id === serviceId) || null;
  }

  function getAvailability(barberUsername = selectedBarberUsername) {
    const key = String(barberUsername ?? "").trim();
    if (!key) return null;

    const defaults = {
      timezone: "America/Chicago",
      bufferMinutes: 0,
      weekly: {
        mon: { enabled: true, start: "09:00", end: "17:00" },
        tue: { enabled: true, start: "09:00", end: "17:00" },
        wed: { enabled: true, start: "09:00", end: "17:00" },
        thu: { enabled: true, start: "09:00", end: "17:00" },
        fri: { enabled: true, start: "09:00", end: "17:00" },
        sat: { enabled: true, start: "09:00", end: "17:00" },
        sun: { enabled: false, start: "09:00", end: "17:00" },
      },
      timeOff: [],
    };

    const parsed = dataStore.getAvailabilityForBarber(key) || {};
    const weekly = {};
    Object.keys(defaults.weekly).forEach((day) => {
      const source = parsed?.weekly?.[day] || {};
      weekly[day] = {
        enabled: Boolean(source.enabled ?? defaults.weekly[day].enabled),
        start: normalizeTime(String(source.start ?? defaults.weekly[day].start)),
        end: normalizeTime(String(source.end ?? defaults.weekly[day].end)),
      };
    });

    const bufferRaw = Number(parsed?.bufferMinutes ?? defaults.bufferMinutes);
    const bufferMinutes = [0, 5, 10, 15].includes(bufferRaw) ? bufferRaw : 0;
    const timeOff = Array.isArray(parsed?.timeOff)
      ? parsed.timeOff
        .map((block) => ({
          id: String(block?.id ?? ""),
          startISO: String(block?.startISO ?? ""),
          endISO: String(block?.endISO ?? ""),
          note: String(block?.note ?? ""),
        }))
        .filter((block) => Number.isFinite(new Date(block.startISO).getTime()) && Number.isFinite(new Date(block.endISO).getTime()))
      : [];

    return {
      timezone: String(parsed?.timezone ?? defaults.timezone),
      bufferMinutes,
      weekly,
      timeOff,
    };
  }

  function renderSlots() {
    if (!slotList) return;

    selectedSlotValue = "";
    updateBookButtonState();

    const shop = getSelectedShop();
    const barber = getSelectedBarber();
    const service = getSelectedService();
    const dateValue = String(bookingDate?.value ?? "");

    if (!shop) {
      slotList.innerHTML = `
        <section class="empty-state">
          <span class="empty-state-icon" aria-hidden="true">S</span>
          <h3>Select a shop</h3>
          <p>Choose a shop to continue booking.</p>
        </section>
      `;
      return;
    }

    if (!barber) {
      slotList.innerHTML = `
        <section class="empty-state">
          <span class="empty-state-icon" aria-hidden="true">S</span>
          <h3>Select a barber</h3>
          <p>Choose a barber to see available services and times.</p>
        </section>
      `;
      return;
    }

    if (!service || !dateValue) {
      slotList.innerHTML = `
        <section class="empty-state">
          <span class="empty-state-icon" aria-hidden="true">S</span>
          <h3>Select service and date</h3>
          <p>Choose a service and date to load available time slots.</p>
        </section>
      `;
      return;
    }

    const slotTimes = generateAvailableSlots({
      barberUsername: barber.username,
      dateYmd: dateValue,
      durationMinutes: service.durationMinutes,
    });

    if (slotTimes.length === 0) {
      slotList.innerHTML = `
        <section class="empty-state">
          <span class="empty-state-icon" aria-hidden="true">S</span>
          <h3>No available times</h3>
          <p>Try another date or service.</p>
        </section>
      `;
      return;
    }

    const slotOptions = slotTimes
      .map((slotTime) => {
        const start = parseLocalDateTime(dateValue, slotTime);
        if (!start) return null;
        const end = new Date(start.getTime() + service.durationMinutes * 60 * 1000);
        const startISO = start.toISOString();
        return {
          startISO,
          label: `${formatDateLocalTime(start)} - ${formatDateLocalTime(end)}`,
        };
      })
      .filter(Boolean);

    slotList.innerHTML = `
      <label for="time-slot-select">Choose a time</label>
      <select id="time-slot-select">
        <option value="">Select a time...</option>
        ${slotOptions.map((slot) => `
          <option value="${escapeHtml(slot.startISO)}">${escapeHtml(slot.label)}</option>
        `).join("")}
      </select>
    `;

    document.getElementById("time-slot-select")?.addEventListener("change", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLSelectElement)) return;
      selectedSlotValue = String(target.value ?? "");
      updateBookButtonState();
    });
  }

  function generateAvailableSlots({ barberUsername, dateYmd, durationMinutes }) {
    const availability = getAvailability(barberUsername);
    if (!availability) return [];

    const date = parseYmd(dateYmd);
    if (!date) return [];

    const dayKey = DAY_KEYS[date.getDay()];
    const day = availability.weekly[dayKey];
    if (!day || day.enabled !== true) return [];

    const dayStartMin = hhmmToMinutes(day.start);
    const dayEndMin = hhmmToMinutes(day.end);
    if (!Number.isFinite(dayStartMin) || !Number.isFinite(dayEndMin) || dayStartMin >= dayEndMin) return [];

    const bookedWindows = getBookedWindowsForBarber(barberUsername, availability.bufferMinutes);
    const timeOffWindows = getTimeOffWindows(availability);
    const nowTs = Date.now();
    const slots = [];

    for (let startMin = dayStartMin; startMin + durationMinutes <= dayEndMin; startMin += SLOT_INCREMENT_MINUTES) {
      const startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, startMin, 0, 0);
      const endDate = new Date(startDate.getTime() + durationMinutes * 60 * 1000);

      if (startDate.getTime() < nowTs) continue;
      if (overlapsAnyWindow(startDate, endDate, bookedWindows)) continue;
      if (overlapsAnyWindow(startDate, endDate, timeOffWindows)) continue;

      slots.push(minutesToHhmm(startMin));
    }

    return slots;
  }

  function getBookedWindowsForBarber(barberUsername, bufferMinutes) {
    return getBookings()
      .filter((booking) => isScheduledStatus(booking?.status))
      .filter((booking) => String(booking?.ownerUsername ?? "") === String(barberUsername ?? ""))
      .filter((booking) => {
        if (!selectedShopId) return true;
        return String(booking?.shopId ?? "") === selectedShopId;
      })
      .map((booking) => getBookingWindow(booking))
      .filter(Boolean)
      .map((window) => ({
        start: window.start,
        end: new Date(window.end.getTime() + bufferMinutes * 60 * 1000),
      }));
  }

  function getTimeOffWindows(availability) {
    if (!availability || !Array.isArray(availability.timeOff)) return [];
    return availability.timeOff
      .map((block) => {
        const start = new Date(block.startISO);
        const end = new Date(block.endISO);
        if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || start >= end) return null;
        return { start, end };
      })
      .filter(Boolean);
  }

  function getBookingWindow(booking) {
    const startIso = String(booking?.startISO ?? booking?.startAtISO ?? "").trim();
    const endIso = String(booking?.endISO ?? "").trim();
    let start = null;
    let end = null;

    if (startIso && endIso) {
      start = new Date(startIso);
      end = new Date(endIso);
    } else {
      const date = String(booking?.date ?? "").trim();
      const time = normalizeTime(String(booking?.time ?? "").trim());
      const duration = Number(booking?.durationMinutes ?? 0);
      const startFromLegacy = parseLocalDateTime(date, time);
      if (startFromLegacy && Number.isFinite(duration) && duration > 0) {
        start = startFromLegacy;
        end = new Date(startFromLegacy.getTime() + duration * 60 * 1000);
      }
    }

    if (!start || !end || !Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || start >= end) {
      return null;
    }
    return { start, end };
  }

  function overlapsAnyWindow(start, end, windows) {
    return windows.some((window) => start < window.end && end > window.start);
  }

  function handleBook() {
    clearStatus();
    const shop = getSelectedShop();
    const barber = getSelectedBarber();
    const service = getSelectedService();
    const depositPolicy = getActiveDepositPolicy();
    const depositRequired = Boolean(depositPolicy.requireDeposit && depositPolicy.depositAmount > 0);
    const depositAmount = depositRequired ? Number(depositPolicy.depositAmount.toFixed(2)) : 0;
    const dateYmd = String(bookingDate?.value ?? "");
    const clientName = String(clientNameInput?.value ?? "").trim();
    const clientContact = String(clientContactInput?.value ?? "").trim();

    if (!shop) {
      setStatus("Please select a shop.", false);
      return;
    }
    if (!barber) {
      setStatus("Please select a barber.", false);
      return;
    }
    if (!service) {
      setStatus("Please select a service.", false);
      return;
    }
    if (!dateYmd) {
      setStatus("Please select a date.", false);
      return;
    }
    if (!selectedSlotValue) {
      setStatus("Please select a time slot.", false);
      return;
    }
    if (!clientName) {
      setStatus("Client name is required.", false);
      return;
    }
    if (!clientContact) {
      setStatus("Client contact is required.", false);
      return;
    }
    if (depositRequired && !depositAcknowledge?.checked) {
      setStatus("Please acknowledge the deposit policy before booking.", false);
      return;
    }

    if (!isLoggedInCustomer) {
      saveClientSession(clientName, clientContact);
      activeClientIdentity = getActiveClientIdentity();
    }

    const availableNow = generateAvailableSlots({
      barberUsername: barber.username,
      dateYmd,
      durationMinutes: service.durationMinutes,
    });
    const availableIsoNow = availableNow
      .map((slotTime) => parseLocalDateTime(dateYmd, slotTime))
      .filter((value) => value instanceof Date)
      .map((value) => value.toISOString());

    if (!availableIsoNow.includes(selectedSlotValue)) {
      setStatus("That slot is no longer available. Please choose another slot.", false);
      renderSlots();
      return;
    }

    const start = new Date(selectedSlotValue);
    if (!Number.isFinite(start.getTime())) {
      setStatus("Invalid slot selection.", false);
      return;
    }
    const end = new Date(start.getTime() + service.durationMinutes * 60 * 1000);
    const ownerUsername = barber.username;

    const booking = {
      id: createId(),
      shopId: shop.id,
      ownerUsername,
      barberUsername: ownerUsername,
      barberDisplayName: barber.displayName,
      shopName: shop.name,
      serviceId: service.id,
      serviceName: service.name,
      durationMinutes: service.durationMinutes,
      price: Number(service.price.toFixed(2)),
      clientName,
      clientContact,
      depositRequired,
      depositAmount,
      depositStatus: depositRequired ? "unpaid" : "not_required",
      startISO: start.toISOString(),
      endISO: end.toISOString(),
      status: "booked",

      // Compatibility fields used by some existing pages/scripts.
      customerUsername: currentUsername || clientName,
      date: toYmd(start),
      time: minutesToHhmm(start.getHours() * 60 + start.getMinutes()),
      startAtISO: start.toISOString(),
      createdAt: new Date().toISOString(),
    };

    const bookings = getBookings();
    bookings.push(booking);
    saveBookings(bookings);
    setLastBookingId(booking.id);

    showToast?.("Booked!", "success");
    selectedSlotValue = "";
    if (depositAcknowledge) depositAcknowledge.checked = false;
    renderDepositPolicyNotice();
    renderSlots();
    renderClientAppointments();
    renderLastBookingPrompt();
    renderBookingReceipt(booking);
  }

  function renderClientAppointments() {
    activeClientIdentity = getActiveClientIdentity();
    if (!activeClientIdentity) {
      renderNextAppointment(null);
      renderMissingIdentityState();
      return;
    }

    const nowTs = Date.now();
    const clientBookings = getBookings()
      .filter((booking) => isBookingForActiveClient(booking))
      .map((booking) => {
        const start = getBookingStartDate(booking);
        const end = getBookingEndDate(booking);
        return { ...booking, _start: start, _end: end };
      })
      .filter((booking) => booking._start instanceof Date && Number.isFinite(booking._start.getTime()));

    const upcoming = clientBookings
      .filter((booking) => isScheduledStatus(booking?.status))
      .filter((booking) => booking._start.getTime() >= nowTs)
      .sort((a, b) => a._start.getTime() - b._start.getTime());

    const past = clientBookings
      .filter((booking) => {
        const status = normalizeAppointmentStatus(booking?.status);
        if (status === "cancelled" || status === "completed" || status === "no-show") return true;
        if (isScheduledStatus(status)) return booking._start.getTime() < nowTs;
        return booking._start.getTime() < nowTs;
      })
      .sort((a, b) => b._start.getTime() - a._start.getTime());

    renderNextAppointment(upcoming[0] || null);
    renderAppointmentList(upcomingList, upcomingEmptyState, upcoming, true);
    renderAppointmentList(pastList, pastEmptyState, past, false);
  }

  function renderMissingIdentityState() {
    const promptMarkup = `
      <section class="empty-state">
        <span class="empty-state-icon" aria-hidden="true">S</span>
        <h3>Book an appointment first</h3>
        <p>We could not find your client session yet.</p>
        <a href="#bookingPanel" class="btn btn-ghost empty-state-cta">Go to booking flow</a>
      </section>
    `;

    if (upcomingList) upcomingList.innerHTML = promptMarkup;
    if (pastList) pastList.innerHTML = "";
    upcomingEmptyState?.classList.add("hidden");
    pastEmptyState?.classList.add("hidden");
  }

  function isBookingForActiveClient(booking) {
    if (!activeClientIdentity) return false;

    if (activeClientIdentity.mode === "username") {
      return String(booking.customerUsername ?? "").trim() === activeClientIdentity.username;
    }

    const bookingContact = normalizeContact(String(booking.clientContact ?? ""));
    const bookingName = String(booking.clientName ?? "").trim().toLowerCase();
    const identityContact = normalizeContact(activeClientIdentity.clientContact);
    const identityName = String(activeClientIdentity.clientName ?? "").trim().toLowerCase();

    if (identityContact && bookingContact === identityContact) return true;
    if (identityName && bookingName && bookingName === identityName) return true;
    return false;
  }

  function normalizeContact(value) {
    return String(value ?? "").trim().toLowerCase();
  }

  function getBookingStartDate(booking) {
    const startIso = String(booking?.startISO ?? booking?.startAtISO ?? "").trim();
    if (startIso) {
      const start = new Date(startIso);
      if (Number.isFinite(start.getTime())) return start;
    }

    const date = String(booking?.date ?? "").trim();
    const time = normalizeTime(String(booking?.time ?? "").trim());
    return parseLocalDateTime(date, time);
  }

  function getBookingEndDate(booking) {
    const endIso = String(booking?.endISO ?? "").trim();
    if (endIso) {
      const end = new Date(endIso);
      if (Number.isFinite(end.getTime())) return end;
    }

    const start = getBookingStartDate(booking);
    const duration = Number(booking?.durationMinutes ?? 0);
    if (!(start instanceof Date) || !Number.isFinite(start.getTime()) || !Number.isFinite(duration)) return null;
    return new Date(start.getTime() + Math.max(1, Math.round(duration)) * 60 * 1000);
  }

  function renderNextAppointment(booking) {
    if (!nextAppointmentDetails || !nextAppointmentEmptyState) return;
    if (!booking) {
      nextAppointmentDetails.classList.add("hidden");
      nextAppointmentEmptyState.classList.remove("hidden");
      return;
    }

    nextAppointmentService.textContent = String(booking.serviceName ?? "Service");
    nextAppointmentDate.textContent = formatDateFriendly(booking._start);
    nextAppointmentTime.textContent = formatDateLocalTime(booking._start);
    if (nextAppointmentStatus) {
      const status = normalizeAppointmentStatus(booking?.status);
      nextAppointmentStatus.textContent = getAppointmentStatusLabel(status);
      nextAppointmentStatus.className = `badge ${getAppointmentStatusBadgeClass(status)}`;
    }
    nextAppointmentDetails.classList.remove("hidden");
    nextAppointmentEmptyState.classList.add("hidden");
  }

  function renderAppointmentList(container, emptyState, rows, allowCancel) {
    if (!container) return;
    container.innerHTML = "";
    emptyState?.classList.toggle("hidden", rows.length > 0);

    rows.forEach((booking) => {
      const start = booking._start;
      const end = booking._end instanceof Date ? booking._end : null;
      const card = document.createElement("article");
      card.className = "appointment-row";

      const startTime = formatDateLocalTime(start);
      const endTime = end && Number.isFinite(end.getTime())
        ? formatDateLocalTime(end)
        : "";
      const statusValue = normalizeAppointmentStatus(booking?.status);
      const statusLabel = getAppointmentStatusLabel(statusValue);
      const statusClass = getAppointmentStatusBadgeClass(statusValue);
      const cancellation = getBookingCancellationState(booking);
      const canCancel = allowCancel && isScheduledStatus(statusValue) && cancellation.canCancel;
      const canDownloadCalendar = allowCancel && isScheduledStatus(statusValue);
      const servicePrice = Number(booking.price ?? 0);
      const durationMinutes = Number(booking.durationMinutes ?? 0);

      card.innerHTML = `
        <div class="appointment-main">${escapeHtml(String(booking.serviceName ?? "Service"))}</div>
        <div class="appointment-datetime">
          <span>${escapeHtml(formatDateFriendly(start))}</span>
          <span>${escapeHtml(startTime)}${endTime ? ` - ${escapeHtml(endTime)}` : ""}</span>
          <span class="small">${escapeHtml(`$${servicePrice.toFixed(2)} | ${durationMinutes} min`)}</span>
          <span class="small">${escapeHtml(`Barber: ${getBookingBarberLabel(booking) || "N/A"}`)}</span>
          <span class="small">${escapeHtml(`Shop: ${getBookingShopLabel(booking) || "N/A"}`)}</span>
          <span class="small">${escapeHtml(`Contact: ${String(booking.clientContact ?? "")}`)}</span>
        </div>
        <div class="appointment-actions">
          <span class="badge ${escapeHtml(statusClass)}">${escapeHtml(statusLabel)}</span>
          ${canDownloadCalendar ? `<button type="button" class="btn btn-ghost btn-compact" data-action="download-calendar" data-id="${escapeHtml(String(booking.id ?? ""))}">Add to Calendar</button>` : ""}
          ${allowCancel && isScheduledStatus(statusValue)
            ? `<button type="button" class="btn btn-ghost btn-compact" data-action="cancel-self" data-id="${escapeHtml(String(booking.id ?? ""))}" ${canCancel ? "" : "disabled"} title="${escapeHtml(cancellation.message)}">Cancel</button>`
            : ""}
        </div>
      `;
      container.appendChild(card);
    });

    container.querySelectorAll('button[data-action="download-calendar"]').forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = String(btn.getAttribute("data-id") ?? "");
        if (!id) return;
        const booking = getBookingById(id) || rows.find((row) => String(row?.id ?? "") === id) || null;
        const errorMessage = downloadIcs(booking);
        if (errorMessage) setStatus(errorMessage, false);
      });
    });

    container.querySelectorAll('button[data-action="cancel-self"]').forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = String(btn.getAttribute("data-id") ?? "");
        if (!id) return;
        cancelSelfBooking(id);
      });
    });
  }

  function getBookingBarberLabel(booking) {
    const explicit = String(booking?.barberDisplayName ?? "").trim();
    if (explicit) return explicit;

    const username = String(booking?.ownerUsername ?? booking?.barberUsername ?? "").trim();
    if (!username) return "";

    const user = dataStore.getUsers().find((item) => String(item?.username ?? "") === username);
    return String(user?.displayName ?? user?.username ?? username).trim() || username;
  }

  function getBookingShopLabel(booking) {
    const explicit = String(booking?.shopName ?? "").trim();
    if (explicit) return explicit;

    const shopId = String(booking?.shopId ?? "").trim();
    if (!shopId) return "";
    const shop = dataStore.getShopById(shopId);
    return String(shop?.name ?? "").trim();
  }

  function cancelSelfBooking(id) {
    const result = cancelBookingById(id, { confirmPrompt: true });
    if (!result.ok) {
      if (!result.cancelledByUser) setStatus(result.message, false);
      return;
    }
    setStatus("Appointment cancelled.", true);
    showToast?.("Appointment cancelled.", "success");
    renderSlots();
    renderClientAppointments();
    renderLastBookingPrompt();

    if (receiptSection && !receiptSection.classList.contains("hidden")) {
      const visibleBookingId = String(receiptSection.dataset.bookingId ?? "").trim();
      if (visibleBookingId && visibleBookingId === String(result.booking?.id ?? "")) {
        renderBookingReceipt(result.booking);
        setReceiptSuccess("Appointment cancelled.");
      }
    }
  }

  function cancelBookingById(id, { confirmPrompt = true } = {}) {
    const targetId = String(id ?? "").trim();
    if (!targetId) {
      return { ok: false, cancelledByUser: false, message: "Appointment not found." };
    }

    const targetBooking = getBookingById(targetId);
    if (!targetBooking) {
      return { ok: false, cancelledByUser: false, message: "Appointment not found." };
    }

    const cancellation = getBookingCancellationState(targetBooking);
    if (!cancellation.canCancel) {
      return { ok: false, cancelledByUser: false, message: cancellation.message };
    }

    if (confirmPrompt && !window.confirm("Cancel this appointment?")) {
      return { ok: false, cancelledByUser: true, message: "" };
    }

    let didCancel = false;
    const bookings = getBookings().map((booking) => {
      if (String(booking?.id ?? "") !== targetId) return booking;
      const nextState = getBookingCancellationState(booking);
      if (!nextState.canCancel) return booking;
      didCancel = true;
      return { ...booking, status: "cancelled" };
    });

    if (!didCancel) {
      return {
        ok: false,
        cancelledByUser: false,
        message: `Cancellations must be made at least ${DEMO_CANCELLATION_WINDOW_HOURS} hours before the appointment starts.`,
      };
    }

    saveBookings(bookings);
    return {
      ok: true,
      cancelledByUser: false,
      message: "",
      booking: getBookingById(targetId) || { ...targetBooking, status: "cancelled" },
    };
  }

  function getBookingCancellationState(booking) {
    const cancellationHours = DEMO_CANCELLATION_WINDOW_HOURS;
    const fallback = {
      canCancel: false,
      cutoffHours: cancellationHours,
      cutoffDate: null,
      message: `Cancellations must be made at least ${cancellationHours} hours before the appointment starts.`,
    };

    if (!booking || typeof booking !== "object") return fallback;
    const status = normalizeAppointmentStatus(booking?.status);
    if (!isScheduledStatus(status)) {
      return {
        ...fallback,
        message: "Only booked or confirmed appointments can be cancelled.",
      };
    }

    const start = getBookingStartDate(booking);
    if (!(start instanceof Date) || !Number.isFinite(start.getTime())) {
      return {
        ...fallback,
        message: "Appointment start time is missing.",
      };
    }

    const cutoffDate = new Date(start.getTime() - cancellationHours * 60 * 60 * 1000);
    if (Date.now() >= cutoffDate.getTime()) {
      return {
        canCancel: false,
        cutoffHours: cancellationHours,
        cutoffDate,
        message: `Cancellations must be made at least ${cancellationHours} hours before the appointment starts.`,
      };
    }

    return {
      canCancel: true,
      cutoffHours: cancellationHours,
      cutoffDate,
      message: `You can cancel until ${formatDateFriendly(cutoffDate)} at ${formatDateLocalTime(cutoffDate)}.`,
    };
  }

  function getManageCancellationHint(booking, cancellation) {
    const status = normalizeAppointmentStatus(booking?.status);
    if (status === "cancelled") return "This appointment has been cancelled.";
    if (status === "completed") return "This appointment is completed.";
    if (status === "no-show") return "This appointment was marked no-show.";
    if (cancellation?.canCancel) {
      return cancellation.message;
    }
    return `Cancellations must be made at least ${DEMO_CANCELLATION_WINDOW_HOURS} hours before start.`;
  }

  function parseYmd(value) {
    const raw = String(value ?? "").trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
    const [yyyy, mm, dd] = raw.split("-").map(Number);
    const date = new Date(yyyy, mm - 1, dd, 0, 0, 0, 0);
    if (
      date.getFullYear() !== yyyy ||
      date.getMonth() !== mm - 1 ||
      date.getDate() !== dd
    ) {
      return null;
    }
    return date;
  }

  function parseLocalDateTime(dateYmd, timeHhmm) {
    const date = parseYmd(dateYmd);
    const minuteOfDay = hhmmToMinutes(timeHhmm);
    if (!date || !Number.isFinite(minuteOfDay)) return null;
    const hours = Math.floor(minuteOfDay / 60);
    const minutes = minuteOfDay % 60;
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), hours, minutes, 0, 0);
  }

  function hhmmToMinutes(value) {
    const time = normalizeTime(String(value ?? ""));
    if (!/^\d{2}:\d{2}$/.test(time)) return NaN;
    const [hh, mm] = time.split(":").map(Number);
    if (!Number.isFinite(hh) || !Number.isFinite(mm) || hh < 0 || hh > 23 || mm < 0 || mm > 59) return NaN;
    return hh * 60 + mm;
  }

  function minutesToHhmm(totalMinutes) {
    const hh = String(Math.floor(totalMinutes / 60)).padStart(2, "0");
    const mm = String(totalMinutes % 60).padStart(2, "0");
    return `${hh}:${mm}`;
  }

  function normalizeTime(value) {
    const raw = String(value ?? "").trim();
    if (/^\d{2}:\d{2}$/.test(raw)) return raw;
    return "";
  }

  function formatTime(time24) {
    const minutes = hhmmToMinutes(time24);
    if (!Number.isFinite(minutes)) return "";
    const hh = Math.floor(minutes / 60);
    const mm = minutes % 60;
    const suffix = hh >= 12 ? "PM" : "AM";
    const hour12 = ((hh + 11) % 12) + 1;
    return `${hour12}:${String(mm).padStart(2, "0")} ${suffix}`;
  }

  function toYmd(date) {
    const yyyy = String(date.getFullYear());
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  }

  function createId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return `b_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  }

  function updateBookButtonState() {
    if (!bookBtn) return;
    bookBtn.disabled = !selectedSlotValue || isDepositAcknowledgementRequired();
  }

  function normalizeAppointmentStatus(statusValue) {
    const status = String(statusValue ?? "booked").trim().toLowerCase();
    if (status === "confirmed") return "confirmed";
    if (status === "completed") return "completed";
    if (status === "cancelled") return "cancelled";
    if (status === "no-show" || status === "no_show" || status === "noshow") return "no-show";
    return "booked";
  }

  function isScheduledStatus(statusValue) {
    const status = normalizeAppointmentStatus(statusValue);
    return status === "booked" || status === "confirmed";
  }

  function getAppointmentStatusLabel(statusValue) {
    const status = normalizeAppointmentStatus(statusValue);
    if (status === "confirmed") return "Confirmed";
    if (status === "completed") return "Completed";
    if (status === "cancelled") return "Cancelled";
    if (status === "no-show") return "No-show";
    return "Booked";
  }

  function getAppointmentStatusBadgeClass(statusValue) {
    const status = normalizeAppointmentStatus(statusValue);
    if (status === "confirmed") return "badge-confirmed";
    if (status === "completed") return "badge-completed";
    if (status === "cancelled") return "badge-cancelled";
    if (status === "no-show") return "badge-no-show";
    return "badge-booked";
  }

  function getBookingDepositDetails(booking) {
    const required = Boolean(booking?.depositRequired);
    const amountRaw = Number(booking?.depositAmount ?? 0);
    const amount = Number.isFinite(amountRaw) && amountRaw > 0
      ? Number(amountRaw.toFixed(2))
      : 0;
    const status = required
      ? String(booking?.depositStatus ?? "unpaid").trim().toLowerCase() || "unpaid"
      : "not_required";

    return {
      required,
      amount,
      status,
    };
  }

  function formatDepositStatusLabel(status) {
    const normalized = String(status ?? "").trim().toLowerCase();
    if (normalized === "paid") return "Paid";
    if (normalized === "waived") return "Waived";
    if (normalized === "not_required") return "Not required";
    return "Unpaid";
  }

  function setStatus(message, success) {
    if (!bookingStatus) return;
    bookingStatus.textContent = String(message ?? "");
    bookingStatus.setAttribute("role", success ? "status" : "alert");
    bookingStatus.setAttribute("aria-live", success ? "polite" : "assertive");
    bookingStatus.setAttribute("aria-atomic", "true");
    bookingStatus.classList.remove("status-success", "status-error");
    bookingStatus.classList.add(success ? "status-success" : "status-error");
  }

  function clearStatus() {
    if (!bookingStatus) return;
    bookingStatus.textContent = "";
    bookingStatus.setAttribute("role", "status");
    bookingStatus.setAttribute("aria-live", "polite");
    bookingStatus.setAttribute("aria-atomic", "true");
    bookingStatus.classList.remove("status-success", "status-error");
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function formatDateLocalTime(date) {
    return new Intl.DateTimeFormat(undefined, {
      hour: "numeric",
      minute: "2-digit",
    }).format(date);
  }

  function formatDateFriendly(date) {
    return new Intl.DateTimeFormat(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
    }).format(date);
  }
})();
