// Reuse the customer booking engine to keep public booking slot rules
// identical to the dashboard booking flow.
import "./customer-dashboard.js";
