import * as dataStore from "./dataStore.js";

const BUFFER_OPTIONS = [0, 5, 10, 15];
const DAY_ORDER = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
const DAY_LABELS = {
  mon: "Monday",
  tue: "Tuesday",
  wed: "Wednesday",
  thu: "Thursday",
  fri: "Friday",
  sat: "Saturday",
  sun: "Sunday",
};

let currentBarberUsername = "";

initOwnerAvailability();

function initOwnerAvailability() {
  const weeklyBody = document.getElementById("availability-weekly-body");
  if (!weeklyBody) return;

  const sessionUser = dataStore.getSessionUser();
  const username = String(sessionUser?.username ?? "").trim();
  const role = String(sessionUser?.role ?? "").toLowerCase();
  const isStaff = role === "owner" || role === "barber";
  if (!username || !isStaff) {
    renderStaffOnlyState();
    return;
  }
  currentBarberUsername = username;

  renderAvailability();
  document.getElementById("availability-save-weekly")?.addEventListener("click", saveWeeklyAvailability);
  document.getElementById("availability-add-timeoff")?.addEventListener("click", addTimeOffBlock);
  weeklyBody.addEventListener("change", handleWeeklyFieldChange);
  document.getElementById("availability-timeoff-list")?.addEventListener("click", handleTimeOffListClick);
}

function renderStaffOnlyState() {
  const section = document.getElementById("owner-availability");
  if (!section) return;
  section.innerHTML = `
    <section class="empty-state">
      <span class="empty-state-icon" aria-hidden="true">S</span>
      <h3>Staff sign-in required</h3>
      <p>Log in as an owner or barber to manage availability.</p>
    </section>
  `;
}

function createDefaultAvailability() {
  return {
    timezone: "America/Chicago",
    bufferMinutes: 0,
    weekly: {
      mon: { enabled: true, start: "09:00", end: "17:00" },
      tue: { enabled: true, start: "09:00", end: "17:00" },
      wed: { enabled: true, start: "09:00", end: "17:00" },
      thu: { enabled: true, start: "09:00", end: "17:00" },
      fri: { enabled: true, start: "09:00", end: "17:00" },
      sat: { enabled: true, start: "09:00", end: "17:00" },
      sun: { enabled: false, start: "09:00", end: "17:00" },
    },
    timeOff: [],
  };
}

function loadAvailability() {
  const defaults = createDefaultAvailability();
  const scoped = dataStore.getAvailabilityForBarber(currentBarberUsername);
  const parsed = scoped && typeof scoped === "object" ? scoped : {};

  const bufferRaw = Number(parsed?.bufferMinutes ?? defaults.bufferMinutes);
  const bufferMinutes = BUFFER_OPTIONS.includes(bufferRaw) ? bufferRaw : defaults.bufferMinutes;
  const timezone = String(parsed?.timezone ?? defaults.timezone).trim() || defaults.timezone;

  const weekly = {};
  DAY_ORDER.forEach((day) => {
    const fallback = defaults.weekly[day];
    const source = parsed?.weekly?.[day] || {};
    weekly[day] = {
      enabled: Boolean(source.enabled ?? fallback.enabled),
      start: normalizeTimeValue(source.start, fallback.start),
      end: normalizeTimeValue(source.end, fallback.end),
    };
  });

  const timeOff = Array.isArray(parsed?.timeOff)
    ? parsed.timeOff
      .map((block) => normalizeTimeOffBlock(block))
      .filter(Boolean)
      .sort((a, b) => a.startISO.localeCompare(b.startISO))
    : [];

  return { timezone, bufferMinutes, weekly, timeOff };
}

function saveAvailability(availability) {
  dataStore.saveAvailabilityForBarber(currentBarberUsername, availability);
}

function renderAvailability() {
  const availability = loadAvailability();
  renderWeeklyTable(availability.weekly);
  renderAvailabilityMeta(availability);
  renderTimeOffList(availability.timeOff);
  clearWeeklyError();
  clearTimeOffError();
}

function renderAvailabilityMeta(availability) {
  const timezoneEl = document.getElementById("availability-timezone");
  const bufferEl = document.getElementById("availability-buffer");
  if (timezoneEl) {
    const hasOption = Array.from(timezoneEl.options).some((opt) => opt.value === availability.timezone);
    if (!hasOption && availability.timezone) {
      const option = document.createElement("option");
      option.value = availability.timezone;
      option.textContent = availability.timezone;
      timezoneEl.appendChild(option);
    }
    timezoneEl.value = availability.timezone;
  }
  if (bufferEl) bufferEl.value = String(availability.bufferMinutes);
}

function renderWeeklyTable(weekly) {
  const body = document.getElementById("availability-weekly-body");
  if (!body) return;

  body.innerHTML = DAY_ORDER.map((day) => {
    const row = weekly[day];
    const disabled = row.enabled ? "" : "disabled";
    return `
      <tr>
        <td>${escapeHtml(DAY_LABELS[day])}</td>
        <td>
          <input
            type="checkbox"
            data-day="${day}"
            data-field="enabled"
            ${row.enabled ? "checked" : ""}
          />
        </td>
        <td>
          <input
            type="time"
            data-day="${day}"
            data-field="start"
            value="${escapeHtml(row.start)}"
            ${disabled}
          />
        </td>
        <td>
          <input
            type="time"
            data-day="${day}"
            data-field="end"
            value="${escapeHtml(row.end)}"
            ${disabled}
          />
        </td>
      </tr>
    `;
  }).join("");
}

function renderTimeOffList(timeOff) {
  const list = document.getElementById("availability-timeoff-list");
  if (!list) return;

  if (!timeOff.length) {
    list.innerHTML = `
      <section class="empty-state">
        <span class="empty-state-icon" aria-hidden="true">S</span>
        <h3>No time off blocks</h3>
        <p>Add planned time off to prevent slot generation.</p>
      </section>
    `;
    return;
  }

  list.innerHTML = `
    <ul class="availability-timeoff-items">
      ${timeOff.map((block) => `
        <li class="availability-timeoff-item">
          <div>
            <strong>${formatLocalDateTime(block.startISO)}</strong>
            <span class="small"> to </span>
            <strong>${formatLocalDateTime(block.endISO)}</strong>
            ${block.note ? `<p class="small">${escapeHtml(block.note)}</p>` : ""}
          </div>
          <button class="btn btn-danger" type="button" data-action="delete-timeoff" data-id="${escapeHtml(block.id)}">Delete</button>
        </li>
      `).join("")}
    </ul>
  `;
}

function handleWeeklyFieldChange(event) {
  const target = event.target;
  if (!(target instanceof HTMLInputElement)) return;
  const day = target.dataset.day;
  const field = target.dataset.field;
  if (!day || !field || !DAY_ORDER.includes(day)) return;
  if (field !== "enabled") return;

  const row = target.closest("tr");
  if (!row) return;
  const enabled = target.checked;
  row.querySelectorAll('input[type="time"]').forEach((timeInput) => {
    timeInput.disabled = !enabled;
  });
}

function saveWeeklyAvailability() {
  const availability = loadAvailability();
  const weekly = {};
  const errors = [];

  DAY_ORDER.forEach((day) => {
    const enabledEl = document.querySelector(`input[data-day="${day}"][data-field="enabled"]`);
    const startEl = document.querySelector(`input[data-day="${day}"][data-field="start"]`);
    const endEl = document.querySelector(`input[data-day="${day}"][data-field="end"]`);

    const enabled = Boolean(enabledEl?.checked);
    const start = String(startEl?.value ?? "");
    const end = String(endEl?.value ?? "");

    if (enabled) {
      if (!start || !end) {
        errors.push(`${DAY_LABELS[day]} requires both start and end times.`);
      } else if (start >= end) {
        errors.push(`${DAY_LABELS[day]} start must be before end.`);
      }
    }

    weekly[day] = {
      enabled,
      start: normalizeTimeValue(start, "09:00"),
      end: normalizeTimeValue(end, "17:00"),
    };
  });

  const timezoneRaw = String(document.getElementById("availability-timezone")?.value ?? "").trim();
  const bufferRaw = Number(document.getElementById("availability-buffer")?.value ?? "0");
  const timezone = timezoneRaw || "America/Chicago";
  const bufferMinutes = BUFFER_OPTIONS.includes(bufferRaw) ? bufferRaw : 0;

  if (errors.length > 0) {
    showWeeklyError(errors.join("<br />"));
    return;
  }

  availability.timezone = timezone;
  availability.bufferMinutes = bufferMinutes;
  availability.weekly = weekly;
  saveAvailability(availability);
  clearWeeklyError();
  renderAvailability();
}

function addTimeOffBlock() {
  const availability = loadAvailability();
  const startLocal = String(document.getElementById("availability-timeoff-start")?.value ?? "");
  const endLocal = String(document.getElementById("availability-timeoff-end")?.value ?? "");
  const note = String(document.getElementById("availability-timeoff-note")?.value ?? "").trim();

  const errors = [];
  if (!startLocal || !endLocal) {
    errors.push("Start and end datetime are required.");
  }

  const startDate = new Date(startLocal);
  const endDate = new Date(endLocal);
  if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) {
    errors.push("Please provide valid start and end datetime values.");
  } else if (startDate >= endDate) {
    errors.push("Time off start must be before end.");
  }

  if (errors.length > 0) {
    showTimeOffError(errors.join("<br />"));
    return;
  }

  availability.timeOff.push({
    id: `to_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`,
    startISO: startDate.toISOString(),
    endISO: endDate.toISOString(),
    note,
  });
  availability.timeOff.sort((a, b) => a.startISO.localeCompare(b.startISO));

  saveAvailability(availability);
  clearTimeOffInputs();
  clearTimeOffError();
  renderAvailability();
}

function handleTimeOffListClick(event) {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;
  const action = target.getAttribute("data-action");
  if (action !== "delete-timeoff") return;

  const id = String(target.getAttribute("data-id") ?? "");
  if (!id) return;

  const availability = loadAvailability();
  const block = availability.timeOff.find((item) => item.id === id);
  if (!block) return;

  const confirmed = window.confirm("Delete this time off block?");
  if (!confirmed) return;

  availability.timeOff = availability.timeOff.filter((item) => item.id !== id);
  saveAvailability(availability);
  renderAvailability();
}

function clearTimeOffInputs() {
  const start = document.getElementById("availability-timeoff-start");
  const end = document.getElementById("availability-timeoff-end");
  const note = document.getElementById("availability-timeoff-note");
  if (start) start.value = "";
  if (end) end.value = "";
  if (note) note.value = "";
}

function showWeeklyError(messageHtml) {
  const el = document.getElementById("availability-weekly-error");
  if (!el) return;
  el.innerHTML = messageHtml;
  el.classList.remove("hidden");
}

function clearWeeklyError() {
  const el = document.getElementById("availability-weekly-error");
  if (!el) return;
  el.innerHTML = "";
  el.classList.add("hidden");
}

function showTimeOffError(messageHtml) {
  const el = document.getElementById("availability-timeoff-error");
  if (!el) return;
  el.innerHTML = messageHtml;
  el.classList.remove("hidden");
}

function clearTimeOffError() {
  const el = document.getElementById("availability-timeoff-error");
  if (!el) return;
  el.innerHTML = "";
  el.classList.add("hidden");
}

function normalizeTimeOffBlock(block) {
  const startISO = String(block?.startISO ?? "");
  const endISO = String(block?.endISO ?? "");
  const start = new Date(startISO);
  const end = new Date(endISO);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || start >= end) return null;
  return {
    id: String(block?.id ?? `to_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`),
    startISO: start.toISOString(),
    endISO: end.toISOString(),
    note: String(block?.note ?? "").trim(),
  };
}

function normalizeTimeValue(value, fallback) {
  const val = String(value ?? "").trim();
  if (/^\d{2}:\d{2}$/.test(val)) return val;
  return fallback;
}

function formatLocalDateTime(isoString) {
  const date = new Date(isoString);
  if (Number.isNaN(date.getTime())) return "Invalid date";
  return date.toLocaleString();
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
