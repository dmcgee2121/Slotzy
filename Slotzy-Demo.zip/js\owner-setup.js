import * as dataStore from "./dataStore.js";

(function () {
  const DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
  const BUFFER_OPTIONS = new Set([0, 5, 10, 15]);

  const state = {
    currentStep: 1,
    username: "",
    shopId: "",
    shopName: "",
    shopSlug: "",
    primaryBarberUsername: "",
    primaryBarberDisplayName: "",
  };

  document.addEventListener("DOMContentLoaded", initSetupWizard);

  function initSetupWizard() {
    const sessionUser = dataStore.getSessionUser();
    const username = String(sessionUser?.username ?? "").trim();
    const role = String(sessionUser?.role ?? "").trim().toLowerCase();
    if (!username || role !== "owner") {
      renderOwnerOnlyState();
      return;
    }

    state.username = username;
    state.primaryBarberUsername = username;

    hydrateDefaults();
    bindEvents();
    showStep(1);
    clearStatus();
  }

  function bindEvents() {
    document.getElementById("setupStep1Next")?.addEventListener("click", handleStep1Next);
    document.getElementById("setupStep2Back")?.addEventListener("click", () => showStep(1));
    document.getElementById("setupStep2Next")?.addEventListener("click", handleStep2Next);
    document.getElementById("setupStep3Back")?.addEventListener("click", () => showStep(2));
    document.getElementById("setupStep3Next")?.addEventListener("click", handleStep3Next);
    document.getElementById("setupStep4Back")?.addEventListener("click", () => showStep(3));
    document.getElementById("setupStep4Next")?.addEventListener("click", handleStep4Next);
    document.getElementById("setupCopyBookingLink")?.addEventListener("click", handleCopyBookingLink);
    document.getElementById("setupOpenBookingPage")?.addEventListener("click", handleOpenBookingPage);
    document.getElementById("setupGoDashboard")?.addEventListener("click", () => {
      window.location.href = "business-owner.html";
    });

    document.querySelectorAll('input[name="setupBarberMode"]').forEach((input) => {
      input.addEventListener("change", handleBarberModeChange);
    });
    handleBarberModeChange();
  }

  function hydrateDefaults() {
    const owner = getOwnerRecord();
    const ownerDisplayName = String(owner?.displayName ?? state.username).trim() || state.username;
    const ownerDisplayNameInput = document.getElementById("setupOwnerDisplayName");
    if (ownerDisplayNameInput) ownerDisplayNameInput.value = ownerDisplayName;
    state.primaryBarberDisplayName = ownerDisplayName;

    const ownerShopId = String(owner?.shopId ?? "").trim();
    if (ownerShopId) {
      const ownerShop = dataStore.getShopById(ownerShopId);
      if (ownerShop) {
        state.shopId = ownerShopId;
        state.shopName = String(ownerShop?.name ?? "").trim();
        state.shopSlug = String(ownerShop?.slug ?? "").trim();
        const shopNameInput = document.getElementById("setupShopName");
        if (shopNameInput && state.shopName) {
          shopNameInput.value = state.shopName;
        }
      }
    }

    const existingServices = getScopedServices().slice(0, 2);
    if (existingServices.length > 0) {
      applyServiceDefaults(existingServices);
    }

    applyAvailabilityDefaults(state.username);
  }

  function handleStep1Next() {
    clearStatus();
    const shopNameInput = document.getElementById("setupShopName");
    const shopName = String(shopNameInput?.value ?? "").trim();
    if (shopName.length < 2) {
      setStatus("Shop name must be at least 2 characters.", false);
      return;
    }

    const shop = upsertOwnerShop(shopName);
    state.shopId = shop.id;
    state.shopName = shop.name;
    state.shopSlug = shop.slug;

    setStatus("Shop details saved.", true);
    showStep(2);
  }

  function handleStep2Next() {
    clearStatus();
    if (!state.shopId) {
      setStatus("Please complete Step 1 first.", false);
      showStep(1);
      return;
    }

    try {
      const mode = getBarberMode();
      if (mode === "owner") {
        const ownerDisplayName = String(
          document.getElementById("setupOwnerDisplayName")?.value ?? ""
        ).trim();
        if (ownerDisplayName.length < 2) {
          setStatus("Owner display name must be at least 2 characters.", false);
          return;
        }

        upsertOwnerDisplayName(ownerDisplayName);
        state.primaryBarberUsername = state.username;
        state.primaryBarberDisplayName = ownerDisplayName;
      } else {
        const barberDisplayName = String(
          document.getElementById("setupBarberDisplayName")?.value ?? ""
        ).trim();
        const barberUsername = String(
          document.getElementById("setupBarberUsername")?.value ?? ""
        ).trim();
        const barberPassword = String(
          document.getElementById("setupBarberPassword")?.value ?? ""
        ).trim();

        if (barberDisplayName.length < 2) {
          setStatus("Barber display name must be at least 2 characters.", false);
          return;
        }
        if (!/^[a-zA-Z0-9._-]{3,32}$/.test(barberUsername)) {
          setStatus("Barber username must be 3-32 chars and can use letters, numbers, dot, dash, or underscore.", false);
          return;
        }
        if (barberPassword.length < 4) {
          setStatus("Barber password must be at least 4 characters.", false);
          return;
        }

        addBarberUser({
          displayName: barberDisplayName,
          username: barberUsername,
          password: barberPassword,
          shopId: state.shopId,
        });
        state.primaryBarberUsername = barberUsername;
        state.primaryBarberDisplayName = barberDisplayName;
      }
    } catch (error) {
      setStatus(String(error?.message ?? "Could not save barber details."), false);
      return;
    }

    setStatus("Barber setup saved.", true);
    showStep(3);
  }

  function handleStep3Next() {
    clearStatus();
    if (!state.shopId) {
      setStatus("Please complete Step 1 first.", false);
      showStep(1);
      return;
    }

    const first = readServiceInput("1");
    const second = readServiceInput("2");
    const services = [first, second];
    const errors = [];

    services.forEach((service, index) => {
      const label = `Service ${index + 1}`;
      if (service.name.length < 2) {
        errors.push(`${label} name must be at least 2 characters.`);
      }
      if (!Number.isFinite(service.price) || service.price <= 0) {
        errors.push(`${label} price must be greater than 0.`);
      }
      if (!Number.isInteger(service.durationMinutes) || service.durationMinutes < 10 || service.durationMinutes > 240) {
        errors.push(`${label} duration must be between 10 and 240 minutes.`);
      }
    });

    if (first.name.toLowerCase() === second.name.toLowerCase()) {
      errors.push("Service names must be unique.");
    }

    if (errors.length > 0) {
      setStatus(errors.join(" "), false);
      return;
    }

    upsertServices(services);
    setStatus("Services saved.", true);
    showStep(4);
  }

  function handleStep4Next() {
    clearStatus();
    if (!state.primaryBarberUsername) {
      setStatus("Please complete Step 2 first.", false);
      showStep(2);
      return;
    }

    const timezone = String(document.getElementById("setupTimezone")?.value ?? "").trim() || "America/Chicago";
    const start = String(document.getElementById("setupHoursStart")?.value ?? "").trim();
    const end = String(document.getElementById("setupHoursEnd")?.value ?? "").trim();
    const selectedDays = new Set(
      Array.from(document.querySelectorAll('.setup-days-grid input[type="checkbox"]:checked'))
        .map((input) => String(input?.value ?? "").trim())
        .filter(Boolean)
    );

    if (!/^\d{2}:\d{2}$/.test(start) || !/^\d{2}:\d{2}$/.test(end)) {
      setStatus("Start and end time are required.", false);
      return;
    }
    if (start >= end) {
      setStatus("Start time must be before end time.", false);
      return;
    }
    if (selectedDays.size === 0) {
      setStatus("Select at least one open day.", false);
      return;
    }

    const existing = dataStore.getAvailabilityForBarber(state.primaryBarberUsername);
    const weekly = {};
    DAY_KEYS.forEach((dayKey) => {
      weekly[dayKey] = {
        enabled: selectedDays.has(dayKey),
        start,
        end,
      };
    });

    dataStore.saveAvailabilityForBarber(state.primaryBarberUsername, {
      ...existing,
      timezone,
      bufferMinutes: sanitizeBufferMinutes(existing?.bufferMinutes),
      weekly,
      timeOff: Array.isArray(existing?.timeOff) ? existing.timeOff : [],
    });

    populateReadyStep();
    setStatus("Weekly hours saved. Setup complete.", true);
    showStep(5);
  }

  function handleBarberModeChange() {
    const mode = getBarberMode();
    const ownerFields = document.getElementById("setupOwnerBarberFields");
    const newBarberFields = document.getElementById("setupNewBarberFields");
    if (!ownerFields || !newBarberFields) return;

    const useOwner = mode === "owner";
    ownerFields.classList.toggle("hidden", !useOwner);
    newBarberFields.classList.toggle("hidden", useOwner);
  }

  function showStep(stepNumber) {
    const step = Number(stepNumber);
    state.currentStep = Number.isFinite(step) ? Math.max(1, Math.min(5, step)) : 1;

    document.querySelectorAll("[data-step-panel]").forEach((panel) => {
      const panelStep = Number(panel.getAttribute("data-step-panel") ?? "0");
      panel.classList.toggle("hidden", panelStep !== state.currentStep);
    });

    document.querySelectorAll(".setup-step").forEach((item) => {
      const itemStep = Number(item.getAttribute("data-step") ?? "0");
      item.classList.toggle("is-active", itemStep === state.currentStep);
      item.classList.toggle("is-complete", itemStep < state.currentStep);
    });
  }

  function upsertOwnerShop(shopName) {
    const owner = getOwnerRecord();
    const existingShopId = String(owner?.shopId ?? "").trim();
    const nextShops = [...dataStore.getShops()];

    let shop = null;
    if (existingShopId) {
      const existingIndex = nextShops.findIndex((row) => String(row?.id ?? "") === existingShopId);
      if (existingIndex >= 0) {
        const existingShop = nextShops[existingIndex];
        shop = {
          ...existingShop,
          name: shopName,
          slug: toSlug(shopName),
        };
        nextShops[existingIndex] = shop;
      }
    }

    if (!shop) {
      const id = existingShopId || createId("shop");
      shop = {
        id,
        name: shopName,
        slug: toSlug(shopName),
        createdAtISO: new Date().toISOString(),
      };

      const sameIdIndex = nextShops.findIndex((row) => String(row?.id ?? "") === id);
      if (sameIdIndex >= 0) {
        nextShops[sameIdIndex] = {
          ...nextShops[sameIdIndex],
          ...shop,
        };
      } else {
        nextShops.push(shop);
      }
    }

    dataStore.saveShops(nextShops);

    const users = [...dataStore.getUsers()];
    const ownerIndex = users.findIndex((user) => String(user?.username ?? "") === state.username);
    const baseOwner = ownerIndex >= 0 ? users[ownerIndex] : {};
    const nextOwner = {
      ...baseOwner,
      username: state.username,
      role: "owner",
      displayName: String(baseOwner?.displayName ?? state.username).trim() || state.username,
      shopId: shop.id,
    };
    if (ownerIndex >= 0) users[ownerIndex] = nextOwner;
    else users.push(nextOwner);
    dataStore.saveUsers(users);

    const session = dataStore.getSessionUser();
    dataStore.setSessionUser({
      ...(session && typeof session === "object" ? session : {}),
      username: state.username,
      role: "owner",
    });

    const legacyShop = dataStore.getShop() || {};
    const legacyPolicy = isRecord(legacyShop.bookingPolicy)
      ? legacyShop.bookingPolicy
      : {};
    dataStore.saveShop({
      ...legacyShop,
      businessName: shopName,
      name: shopName,
      shopId: shop.id,
      bookingPolicy: {
        ...getDefaultBookingPolicy(),
        ...legacyPolicy,
      },
      updatedAt: new Date().toISOString(),
    });

    return shop;
  }

  function upsertOwnerDisplayName(displayName) {
    const users = [...dataStore.getUsers()];
    const ownerIndex = users.findIndex((user) => String(user?.username ?? "") === state.username);
    const baseOwner = ownerIndex >= 0 ? users[ownerIndex] : {};
    const nextOwner = {
      ...baseOwner,
      username: state.username,
      role: "owner",
      displayName,
      shopId: state.shopId || String(baseOwner?.shopId ?? "").trim() || null,
    };
    if (ownerIndex >= 0) users[ownerIndex] = nextOwner;
    else users.push(nextOwner);
    dataStore.saveUsers(users);
  }

  function addBarberUser({ displayName, username, password, shopId }) {
    const users = [...dataStore.getUsers()];
    const duplicate = users.some(
      (user) => String(user?.username ?? "").toLowerCase() === username.toLowerCase()
    );
    if (duplicate) {
      throw new Error("That barber username is already in use.");
    }

    users.push({
      username,
      password,
      role: "barber",
      shopId,
      displayName,
    });
    dataStore.saveUsers(users);
  }

  function upsertServices(serviceRows) {
    const allServices = [...dataStore.getServices()];
    const barberUsername = state.primaryBarberUsername || state.username;
    const nowIso = new Date().toISOString();

    serviceRows.forEach((row) => {
      const lookupName = row.name.toLowerCase();
      const existingIndex = allServices.findIndex((service) => {
        const serviceName = String(service?.name ?? service?.title ?? "").trim().toLowerCase();
        const serviceShopId = String(service?.shopId ?? "").trim();
        const serviceBarber = String(service?.barberUsername ?? service?.ownerUsername ?? "").trim();
        return serviceShopId === state.shopId && serviceBarber === barberUsername && serviceName === lookupName;
      });

      const normalized = {
        id: existingIndex >= 0
          ? String(allServices[existingIndex]?.id ?? createId("svc"))
          : createId("svc"),
        name: row.name,
        title: row.name,
        price: Number(row.price.toFixed(2)),
        durationMinutes: row.durationMinutes,
        duration: row.durationMinutes,
        active: true,
        createdAtISO: existingIndex >= 0
          ? String(allServices[existingIndex]?.createdAtISO ?? nowIso)
          : nowIso,
        shopId: state.shopId,
        barberUsername,
        ownerUsername: barberUsername,
      };

      if (existingIndex >= 0) allServices[existingIndex] = { ...allServices[existingIndex], ...normalized };
      else allServices.push(normalized);
    });

    dataStore.saveServices(allServices);
  }

  function populateReadyStep() {
    const shop = resolveCurrentShop();
    const shopName = String(shop?.name ?? state.shopName ?? "").trim();
    const shopSlug = String(shop?.slug ?? state.shopSlug ?? "").trim();
    const bookingLink = buildBookingLink(shopSlug);

    state.shopName = shopName;
    state.shopSlug = shopSlug;

    const readyShopName = document.getElementById("setupReadyShopName");
    const readyBarberName = document.getElementById("setupReadyBarberName");
    const bookingLinkInput = document.getElementById("setupBookingLink");
    if (readyShopName) readyShopName.textContent = shopName || "My Shop";
    if (readyBarberName) {
      readyBarberName.textContent = state.primaryBarberDisplayName || state.primaryBarberUsername || state.username;
    }
    if (bookingLinkInput) bookingLinkInput.value = bookingLink;
  }

  async function handleCopyBookingLink() {
    const bookingLinkInput = document.getElementById("setupBookingLink");
    const value = String(bookingLinkInput?.value ?? "").trim();
    if (!value) {
      setStatus("Booking link is not ready yet.", false);
      return;
    }

    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
        await navigator.clipboard.writeText(value);
      } else if (bookingLinkInput instanceof HTMLInputElement) {
        bookingLinkInput.focus();
        bookingLinkInput.select();
        const copied = document.execCommand("copy");
        if (!copied) throw new Error("copy_failed");
      } else {
        throw new Error("copy_failed");
      }
      setStatus("Booking link copied.", true);
    } catch {
      setStatus("Could not copy link. Please copy it manually.", false);
    }
  }

  function handleOpenBookingPage() {
    const shopSlug = String(state.shopSlug ?? "").trim();
    if (!shopSlug) {
      setStatus("Booking link is not ready yet.", false);
      return;
    }
    window.location.href = `book.html?shop=${encodeURIComponent(shopSlug)}`;
  }

  function readServiceInput(index) {
    const name = String(document.getElementById(`setupService${index}Name`)?.value ?? "").trim();
    const price = Number(document.getElementById(`setupService${index}Price`)?.value ?? "");
    const durationMinutes = Math.round(Number(document.getElementById(`setupService${index}Duration`)?.value ?? ""));
    return { name, price, durationMinutes };
  }

  function applyServiceDefaults(services) {
    const first = services[0];
    const second = services[1];
    if (first) fillServiceInputs("1", first);
    if (second) fillServiceInputs("2", second);
  }

  function fillServiceInputs(index, service) {
    const nameInput = document.getElementById(`setupService${index}Name`);
    const priceInput = document.getElementById(`setupService${index}Price`);
    const durationInput = document.getElementById(`setupService${index}Duration`);
    if (nameInput && !String(nameInput.value ?? "").trim()) {
      nameInput.value = String(service?.name ?? service?.title ?? "").trim();
    }
    if (priceInput && !String(priceInput.value ?? "").trim()) {
      const price = Number(service?.price ?? NaN);
      if (Number.isFinite(price) && price > 0) priceInput.value = String(price);
    }
    if (durationInput && !String(durationInput.value ?? "").trim()) {
      const duration = Number(service?.durationMinutes ?? service?.duration ?? NaN);
      if (Number.isFinite(duration) && duration > 0) durationInput.value = String(Math.round(duration));
    }
  }

  function applyAvailabilityDefaults(username) {
    const availabilityMap = dataStore.getAvailabilityMap();
    const entry = availabilityMap?.[username];
    if (!isRecord(entry)) return;
    if (!isRecord(entry.weekly)) return;

    const timezone = String(entry.timezone ?? "").trim();
    const timezoneInput = document.getElementById("setupTimezone");
    if (timezoneInput && timezone) {
      const hasTimezoneOption = Array.from(timezoneInput.options).some((option) => option.value === timezone);
      if (!hasTimezoneOption) {
        const option = document.createElement("option");
        option.value = timezone;
        option.textContent = timezone;
        timezoneInput.appendChild(option);
      }
      timezoneInput.value = timezone;
    }

    const enabledDays = DAY_KEYS.filter((dayKey) => Boolean(entry?.weekly?.[dayKey]?.enabled));
    if (enabledDays.length > 0) {
      document.querySelectorAll('.setup-days-grid input[type="checkbox"]').forEach((input) => {
        const day = String(input?.value ?? "").trim();
        input.checked = enabledDays.includes(day);
      });
    }

    const sampleDay = enabledDays[0] || DAY_KEYS.find((dayKey) => isRecord(entry?.weekly?.[dayKey]));
    if (!sampleDay) return;

    const sampleStart = String(entry?.weekly?.[sampleDay]?.start ?? "").trim();
    const sampleEnd = String(entry?.weekly?.[sampleDay]?.end ?? "").trim();
    if (/^\d{2}:\d{2}$/.test(sampleStart)) {
      const startInput = document.getElementById("setupHoursStart");
      if (startInput) startInput.value = sampleStart;
    }
    if (/^\d{2}:\d{2}$/.test(sampleEnd)) {
      const endInput = document.getElementById("setupHoursEnd");
      if (endInput) endInput.value = sampleEnd;
    }
  }

  function getScopedServices() {
    const scoped = dataStore.getServices().filter((service) => {
      if (state.shopId) return String(service?.shopId ?? "").trim() === state.shopId;
      const barberUsername = String(service?.barberUsername ?? service?.ownerUsername ?? "").trim();
      return barberUsername === state.username;
    });
    return scoped.sort((a, b) => {
      const left = String(a?.createdAtISO ?? "");
      const right = String(b?.createdAtISO ?? "");
      return left.localeCompare(right);
    });
  }

  function resolveCurrentShop() {
    if (state.shopId) {
      const direct = dataStore.getShopById(state.shopId);
      if (direct) return direct;
    }

    const owner = getOwnerRecord();
    const ownerShopId = String(owner?.shopId ?? "").trim();
    if (ownerShopId) {
      const ownerShop = dataStore.getShopById(ownerShopId);
      if (ownerShop) return ownerShop;
    }

    const fallback = dataStore.getShopForUser(state.username);
    if (fallback) return fallback;
    return null;
  }

  function getOwnerRecord() {
    return dataStore.getUsers().find((user) => String(user?.username ?? "") === state.username) || null;
  }

  function getBarberMode() {
    const selected = document.querySelector('input[name="setupBarberMode"]:checked');
    return String(selected?.value ?? "owner").trim().toLowerCase() === "new"
      ? "new"
      : "owner";
  }

  function buildBookingLink(slug) {
    const normalizedSlug = String(slug ?? "").trim();
    if (!normalizedSlug) return "";
    const origin = String(window.location.origin ?? "").trim();
    if (!origin) return `/pages/book.html?shop=${encodeURIComponent(normalizedSlug)}`;
    return `${origin}/pages/book.html?shop=${encodeURIComponent(normalizedSlug)}`;
  }

  function sanitizeBufferMinutes(value) {
    const parsed = Number(value);
    return BUFFER_OPTIONS.has(parsed) ? parsed : 0;
  }

  function setStatus(message, isSuccess) {
    const statusEl = document.getElementById("setupStatus");
    if (!statusEl) return;
    statusEl.textContent = String(message ?? "");
    statusEl.setAttribute("role", isSuccess ? "status" : "alert");
    statusEl.setAttribute("aria-live", isSuccess ? "polite" : "assertive");
    statusEl.setAttribute("aria-atomic", "true");
    statusEl.classList.remove("status-success", "status-error");
    statusEl.classList.add(isSuccess ? "status-success" : "status-error");
  }

  function clearStatus() {
    const statusEl = document.getElementById("setupStatus");
    if (!statusEl) return;
    statusEl.textContent = "";
    statusEl.setAttribute("role", "status");
    statusEl.setAttribute("aria-live", "polite");
    statusEl.setAttribute("aria-atomic", "true");
    statusEl.classList.remove("status-success", "status-error");
  }

  function renderOwnerOnlyState() {
    const main = document.getElementById("ownerSetupMain");
    if (!main) return;
    main.innerHTML = `
      <section class="card owner-panel" style="max-width: 560px; margin: 2rem auto; text-align: center;">
        <h1>Owner sign-in required.</h1>
        <p class="small">Please sign in as an owner to run setup.</p>
        <a href="../index.html" class="btn btn-primary">Go to Home</a>
      </section>
    `;
  }

  function getDefaultBookingPolicy() {
    return {
      allowSameDay: true,
      maxDaysAdvance: 30,
      cancelHours: 24,
      bufferMinutes: 0,
      requireDeposit: false,
      depositAmount: 0,
      lateGraceMinutes: 10,
      noShowStrikeLimit: 2,
    };
  }

  function createId(prefix) {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return `${prefix}_${window.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  }

  function toSlug(value) {
    return String(value ?? "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || `shop-${Date.now()}`;
  }

  function isRecord(value) {
    return Boolean(value && typeof value === "object" && !Array.isArray(value));
  }
})();
